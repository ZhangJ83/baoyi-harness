import json
from pathlib import Path

from benchmarks.objective_gate import build


def test_objective_gate_does_not_promote_structural_ppt_or_local_review(tmp_path: Path):
    (tmp_path / "workspace/results").mkdir(parents=True)
    (tmp_path / "research/review").mkdir(parents=True)
    (tmp_path / "research").mkdir(exist_ok=True)
    (tmp_path / "workspace/results/completion_audit_current.json").write_text(
        json.dumps({"checks": {"official_terminal_bench": {"status": "pilot_only"},
                                 "official_swe_bench_verified": {"status": "agent_pilot_only"}}}),
        encoding="utf-8",
    )
    (tmp_path / "workspace/results/claims_gate_current.json").write_text(
        json.dumps({"claim_allowed": True, "superiority_supported": False}), encoding="utf-8"
    )
    (tmp_path / "research/paper_experiment_matrix.json").write_text(
        json.dumps({"experiments": []}), encoding="utf-8"
    )
    (tmp_path / "benchmarks").mkdir()
    (tmp_path / "benchmarks/official_matched_protocol.json").write_text(
        json.dumps({"budget_enforcement": {"budget_parity_verified": False}}),
        encoding="utf-8",
    )
    result = build(tmp_path)
    assert result["objective_complete"] is False
    assert result["checks"]["model_generated_ppt_evaluation"]["achieved"] is False
    assert result["checks"]["external_independent_review"]["achieved"] is False
    assert result["checks"]["matched_claude_codex_protocol"]["achieved"] is False
