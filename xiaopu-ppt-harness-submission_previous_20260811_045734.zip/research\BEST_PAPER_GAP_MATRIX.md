# ICLR Best Paper gap matrix

Audit time: 2026-08-10 15:52

This matrix is deliberately strict: a green controlled demo is not promoted to
a publication-scale claim. Each row names the evidence that would close the
gap and the current blocker.

| Requirement | Current evidence | Status | Exact closure condition | Next action |
|---|---|---|---|---|
| Core problem and mechanism | CEGAR-H formulation, mutation epochs, typed evidence, adaptive action table | supported in prototype | Independent implementation audit and real-task ablation | Freeze runtime config and publish code path |
| Fresh-evidence safety | 71-test regression, post-edit certificate rejection, controlled PPT trace, static audit of 14 registered PPT mutators | controlled-supported | Runtime mutation instrumentation coverage audit across all mutators and external side effects | Add property-based mutation trace and external-side-effect boundary test |
| Theory | Plug-in bounds, correlation bound, dynamic-oracle counterexample, finite checks | bounded-supported | Formal proof review with assumptions checked line by line | External theory review |
| Synthetic mechanism effect | 20-seed paired ablations, calibration shift, held-out calibration | synthetic-only | Held-out real-task trajectories with cost/risk labels | Collect real traces under fixed budget |
| PPT artifact workflow | 4-slide rendered demo, 4 PNGs, montage, structural score 1.0, pixel audit pass | controlled-rendered-demo | Frozen model-generated PPT task slice with blinded semantic/visual review | Run PPTBench after API/infrastructure gate |
| Terminal-Bench | 3/241 official pilot tasks, 3/3 | pilot-only | Declared 18-task matched slice at minimum; full score for leaderboard claims | Enable pagefile and run pinned slice |
| SWE-bench Verified | 1 score-eligible instance | agent-pilot-only | At least 10 instances for multi-instance evidence; full Verified for benchmark claim | Run exact-commit evaluator |
| Competitor comparison | 3-task raw comparison; budget parity false | exploratory-only | Same task ids, provider ledger, token/tool/step/wall-clock caps, n≥18, paired tests | Implement shared gateway ledger |
| Causal attribution | Controller validated mainly in simulator | missing real causality | Full controller vs direct/always-verify/evidence-only on identical real tasks | Enable opt-in controller and preregister run |
| Independent review | Local skeptical review | pending | Dated independent report from a non-author reviewer | Send paper and evidence packet |
| Claim boundary | Machine audit explicitly reports incomplete objective | honest | Only promote claims whose row is closed | Keep claim gate fail-closed |

## Decision

The strongest current submission is a bounded theory-and-engineering paper with a
controlled rendered PPT demonstration. It is not yet an ICLR Best Paper claim.
The highest-information next experiment is not another synthetic sweep: it is
the same-budget real-task ablation with the CEGAR-H controller enabled, followed
by the 18-task matched slice.
