"""Non-interactive benchmark adapter for containerized coding tasks."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import os
import sys
import time
from pathlib import Path


def is_provider_unavailable(error_text: str) -> bool:
    """Return whether an exception string denotes an infrastructure outage."""
    lowered = error_text.lower()
    return any(
        marker in lowered
        for marker in ("apiconnectionerror", "connection error", "timeout", "timed out")
    )


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Xiaopu in a benchmark workspace")
    parser.add_argument("task", nargs="*", help="task text; stdin is used when omitted")
    parser.add_argument("--workspace", required=True, help="isolated task workspace")
    parser.add_argument("--model")
    parser.add_argument("--max-steps", type=int, default=60)
    parser.add_argument("--max-tool-calls", type=int, default=240)
    parser.add_argument("--max-total-tokens", type=int, default=180000)
    parser.add_argument("--log", default=".xiaopu/run.jsonl")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _arguments()
    workspace = Path(args.workspace).resolve()
    if not workspace.is_dir():
        print(f"workspace is not a directory: {workspace}", file=sys.stderr)
        return 2
    task = " ".join(args.task).strip() or sys.stdin.read().strip()
    if not task:
        print("task is empty", file=sys.stderr)
        return 2

    os.environ["WORKSPACE"] = str(workspace)
    os.environ["COMMAND_POLICY"] = "allow"
    os.environ["ISOLATED_BENCHMARK"] = "1"
    os.environ["MAX_STEPS"] = str(args.max_steps)
    os.environ["MAX_TOOL_CALLS"] = str(args.max_tool_calls)
    os.environ["MAX_TOTAL_TOKENS"] = str(args.max_total_tokens)
    # Benchmark runs must not spend budget retrying an unavailable provider.
    # Users can explicitly override this for a controlled robustness study.
    os.environ.setdefault("API_RETRIES", "0")

    from .harness import Harness
    from .redact import redact

    log_path = (workspace / args.log).resolve()
    try:
        log_path.relative_to(workspace)
    except ValueError:
        print("log path escapes workspace", file=sys.stderr)
        return 2
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    def record(kind: str, payload: dict) -> None:
        event = {"time": time.time(), "kind": kind, **payload}
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(redact(json.dumps(event, ensure_ascii=False)) + "\n")

    harness = Harness(model=args.model, max_steps=args.max_steps)
    harness.attach_printer(
        lambda name, tool_args, output: record(
            "tool",
            {"name": name, "arguments": redact(tool_args[:4000]), "output": redact(output[:12000])},
        )
    )
    record("start", {"model": harness.llm.model, "task": task, "workspace": str(workspace)})
    try:
        answer = harness.run(task)
        status = "completed" if harness.state.final_summary else "stopped"
        code = 0 if status == "completed" else 1
    except Exception as exc:
        answer = f"{type(exc).__name__}: {exc}"
        # Provider outages are infrastructure diagnostics, not task failures.
        # Keep them explicit so a benchmark aggregator can exclude them from
        # success denominators without silently treating them as completions.
        unavailable = is_provider_unavailable(answer)
        status = "provider_unavailable" if unavailable else "error"
        code = 3 if unavailable else 1
    summary = {
        "status": status,
        "answer": answer,
        "tool_calls": harness.state.tool_calls,
        "total_tokens": harness.state.total_tokens,
        "changed_files": sorted(harness.state.changed_files),
        "evidence": [asdict(record) for record in harness.state.evidence],
        "budget_overrun": harness.state.budget_overrun,
        "elapsed_seconds": round(time.time() - started, 3),
    }
    record("finish", summary)
    print(redact(json.dumps(summary, ensure_ascii=False) if args.json else answer))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
