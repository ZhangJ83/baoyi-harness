"""Terminal-Bench adapter for the Xiaopu command policy.

The adapter deliberately uses Terminal-Bench's BaseAgent/TmuxSession contract
so official task scoring remains responsible for container setup and tests.
It asks the configured benchmark LLM for a small JSON command batch, executes
it in the official session, then asks for one focused follow-up batch.
"""

import json
from pathlib import Path

from pydantic import BaseModel, Field
from terminal_bench.agents.base_agent import AgentResult, BaseAgent
from terminal_bench.agents.failure_mode import FailureMode
from terminal_bench.llms.lite_llm import LiteLLM
from terminal_bench.terminal.tmux_session import TmuxSession
from agent.safety import sensitive_output
from agent.budget import BudgetLedger


class CommandBatch(BaseModel):
    commands: list[str] = Field(default_factory=list)
    done: bool = False


class XiaopuTerminalAgent(BaseAgent):
    def __init__(
        self,
        model_name: str = "openai/deepseek-v4-flash",
        llm=None,
        api_base: str | None = None,
        temperature: float = 0.0,
        max_total_tokens: int = 12_000,
        max_output_tokens: int = 1_500,
        max_tool_calls: int = 60,
        max_steps: int = 3,
        **kwargs,
    ):
        super().__init__(**kwargs)
        # Terminal-Bench's AgentFactory passes model_name/agent kwargs rather
        # than injecting an LLM object.  Keeping the optional llm argument
        # makes the adapter easy to unit-test while matching the official
        # factory contract in real runs.
        self._llm = llm or LiteLLM(
            model_name=model_name,
            api_base=api_base,
            temperature=temperature,
        )
        self._max_total_tokens = max(1, int(max_total_tokens))
        self._max_output_tokens = max(1, int(max_output_tokens))
        self._max_tool_calls = max(1, int(max_tool_calls))
        self._max_steps = max(1, int(max_steps))

    @staticmethod
    def name() -> str:
        return "xiaopu"

    @staticmethod
    def _sensitive_output(command: str) -> bool:
        """Reject commands that would print likely secrets into the transcript."""
        return sensitive_output(command)

    def perform_task(self, instruction: str, session: TmuxSession, logging_dir: Path | None = None) -> AgentResult:
        ledger = BudgetLedger(
            max_total_tokens=self._max_total_tokens,
            max_tool_calls=self._max_tool_calls,
            max_steps=self._max_steps,
        )
        transcript: list[str] = []
        budget_exhausted = False

        def finish(failure_mode: FailureMode) -> AgentResult:
            """Persist and return the ledger on every exit path, including errors."""
            if logging_dir is not None:
                logging_dir.mkdir(parents=True, exist_ok=True)
                (logging_dir / "xiaopu_commands.json").write_text(
                    json.dumps(transcript, indent=2), encoding="utf-8"
                )
                (logging_dir / "budget_ledger.json").write_text(
                    json.dumps(
                        ledger.snapshot(system="xiaopu", failure_mode=failure_mode.value),
                        indent=2,
                    ),
                    encoding="utf-8",
                )
            return AgentResult(
                total_input_tokens=ledger.input_tokens,
                total_output_tokens=ledger.output_tokens,
                failure_mode=failure_mode,
            )

        for turn in range(self._max_steps):
            if not ledger.begin_step():
                budget_exhausted = True
                break
            try:
                observation = session.capture_pane(capture_entire=False)[-6000:]
            except Exception:
                return finish(FailureMode.UNKNOWN_AGENT_ERROR)
            prompt = (
                "You are Xiaopu operating a Terminal-Bench container.\n"
                "Return JSON only: {\\\"commands\\\":[...],\\\"done\\\":true|false}.\n"
                "Use short, safe shell commands. Complete the task and verify it.\n"
                "Before declaring done, run a task-specific postcondition check: for executable/permission tasks use test -x and invoke the script; for file-creation tasks use test -f plus exact content/size checks; for archive tasks inspect the archive member list, extract only the required member, and test the output path. Then run the provided tests.\n"
                "Keep the JSON compact: emit at most 3 commands per turn. For a permission task, inspect the mode, apply the minimal chmod fix, and invoke the script; do not narrate or emit long shell pipelines.\n"
                "Never print file contents, secrets, or solution text. For sensitive files, use only metadata checks such as test -s, wc -c, sha256sum, or cmp.\n"
                "For archive tasks, extract only the required member and avoid recursive/untrusted paths.\n"
                f"Task: {instruction}\n"
                f"Current terminal output:\n{observation}\n"
                f"This is turn {turn + 1}/{self._max_steps}."
            )
            input_tokens = self._llm.count_tokens([{"role": "user", "content": prompt}])
            if not ledger.record_tokens(input_tokens, 0):
                return finish(FailureMode.AGENT_TIMEOUT)
            try:
                raw = self._llm.call(prompt, max_tokens=self._max_output_tokens)
            except TypeError:
                # Keep tiny test doubles compatible with the official BaseLLM
                # contract while enforcing max_tokens for LiteLLM in production.
                try:
                    raw = self._llm.call(prompt)
                except Exception:
                    return finish(FailureMode.UNKNOWN_AGENT_ERROR)
            except Exception:
                return finish(FailureMode.UNKNOWN_AGENT_ERROR)
            output_tokens = self._llm.count_tokens([{"role": "assistant", "content": raw}])
            if not ledger.record_tokens(0, output_tokens):
                return finish(FailureMode.AGENT_TIMEOUT)
            try:
                batch = CommandBatch.model_validate_json(raw)
            except Exception:
                # A provider can truncate a long JSON response even when the
                # requested action was simple. Spend one bounded repair call
                # instead of converting the task immediately into a fatal
                # parse error; the repair prompt forbids narration and asks
                # for a minimal command batch.
                repair_prompt = (
                    "Return only compact valid JSON in exactly this schema: "
                    '{"commands":[],"done":false}. Preserve only the minimal '
                    "commands needed to complete and verify the task. No prose.\n"
                    f"Task: {instruction}\nTerminal output:\n{observation}"
                )
                repair_in = self._llm.count_tokens([{"role": "user", "content": repair_prompt}])
                if not ledger.record_tokens(repair_in, 0):
                    return finish(FailureMode.AGENT_TIMEOUT)
                try:
                    repair_raw = self._llm.call(
                        repair_prompt,
                        max_tokens=min(self._max_output_tokens, 512),
                    )
                except TypeError:
                    try:
                        repair_raw = self._llm.call(repair_prompt)
                    except Exception:
                        return finish(FailureMode.UNKNOWN_AGENT_ERROR)
                except Exception:
                    return finish(FailureMode.UNKNOWN_AGENT_ERROR)
                repair_out = self._llm.count_tokens([{"role": "assistant", "content": repair_raw}])
                if not ledger.record_tokens(0, repair_out):
                    return finish(FailureMode.AGENT_TIMEOUT)
                try:
                    batch = CommandBatch.model_validate_json(repair_raw)
                    raw = repair_raw
                except Exception:
                    return finish(FailureMode.FATAL_LLM_PARSE_ERROR)
            remaining_calls = max(0, self._max_tool_calls - ledger.tool_calls)
            for command in batch.commands[: min(8, remaining_calls)]:
                if not ledger.record_tool():
                    budget_exhausted = True
                    break
                if self._sensitive_output(command):
                    warning = "echo 'BLOCKED: do not print sensitive file contents; use metadata-only verification'"
                    try:
                        session.send_keys([warning, "Enter"], block=True)
                    except Exception:
                        return finish(FailureMode.UNKNOWN_AGENT_ERROR)
                    transcript.append(f"BLOCKED: {command}")
                    continue
                try:
                    session.send_keys([command, "Enter"], block=True)
                except Exception:
                    return finish(FailureMode.UNKNOWN_AGENT_ERROR)
                transcript.append(command)
            if ledger.tool_calls >= self._max_tool_calls or ledger.total_tokens >= self._max_total_tokens:
                budget_exhausted = True
            if batch.done:
                break
        return finish(FailureMode.AGENT_TIMEOUT if budget_exhausted else FailureMode.NONE)
