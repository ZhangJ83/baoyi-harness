import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pptx import Presentation
from PIL import Image, ImageDraw

from agent.state import RunState
from agent.tools.registry import dispatch
from agent.tools.registry import _PPT_MUTATORS


class DummyHarness:
    def __init__(self):
        self.state = RunState()
        self.deck = None


class PowerPointTests(unittest.TestCase):
    def test_build_verify_save(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"WORKSPACE": tmp}):
            h = DummyHarness()
            dispatch("new_deck", json.dumps({"title": "Test", "subtitle": "Evidence"}), h)
            dispatch("add_slide", json.dumps({"title": "Result", "bullets": ["One", "Two"]}), h)
            report = dispatch("ppt_verify", "{}", h)
            self.assertIn("no structural issues", report)
            dispatch("save_deck", json.dumps({"path": "deck.pptx"}), h)
            self.assertEqual(len(Presentation(Path(tmp) / "deck.pptx").slides), 2)

    def test_open_inventory_replace_and_two_column(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"WORKSPACE": tmp}):
            source = Presentation()
            slide = source.slides.add_slide(source.slide_layouts[6])
            box = slide.shapes.add_textbox(0, 0, 2000000, 500000)
            box.text = "Before"
            source.save(Path(tmp) / "source.pptx")
            h = DummyHarness()
            dispatch("open_deck", json.dumps({"path": "source.pptx"}), h)
            inventory = dispatch("shape_inventory", json.dumps({"slide_number": 1}), h)
            self.assertIn("Before", inventory)
            dispatch("replace_shape_text", json.dumps({"slide_number": 1, "shape_id": box.shape_id, "text": "After"}), h)
            dispatch("add_two_column_slide", json.dumps({"title": "Compare", "left_title": "A", "left_bullets": ["one"], "right_title": "B", "right_bullets": ["two"]}), h)
            self.assertIn("After", dispatch("shape_inventory", json.dumps({"slide_number": 1}), h))
            self.assertEqual(len(h.deck.slides), 2)

    def test_metric_and_table_layouts_verify(self):
        h = DummyHarness()
        dispatch("add_metric_slide", json.dumps({"title": "KPIs", "metrics": [{"value": "42%", "label": "Win rate", "detail": "+5pp"}], "takeaway": "Improving"}), h)
        dispatch("add_table_slide", json.dumps({"title": "Options", "columns": ["Name", "Score"], "rows": [["A", "9"], ["B", "7"]]}), h)
        dispatch("add_process_slide", json.dumps({"title": "Method", "steps": [{"title": "A", "detail": "Inspect"}, {"title": "B", "detail": "Edit"}, {"title": "C", "detail": "Verify"}]}), h)
        self.assertIn("no structural issues", dispatch("ppt_verify", "{}", h))

    def test_edit_primitives_invalidate_prior_evidence(self):
        h = DummyHarness()
        dispatch("new_deck", json.dumps({"title": "Cover"}), h)
        dispatch("add_slide", json.dumps({"title": "First", "bullets": ["A"]}), h)
        dispatch("add_slide", json.dumps({"title": "Second", "bullets": ["B"]}), h)
        dispatch("ppt_verify", "{}", h)
        self.assertTrue(h.state.fresh_evidence())

        target = next(shape for shape in h.deck.slides[1].shapes if shape.has_text_frame and shape.text_frame.text == "First")
        dispatch("set_shape_geometry", json.dumps({"slide_number": 2, "shape_id": target.shape_id, "x": 1.0, "y": 0.5, "w": 8.0, "height": 0.7}), h)
        self.assertFalse(h.state.fresh_evidence())
        dispatch("ppt_verify", "{}", h)
        self.assertTrue(h.state.fresh_evidence())

        dispatch("move_slide", json.dumps({"slide_number": 3, "new_position": 2}), h)
        self.assertFalse(h.state.fresh_evidence())
        dispatch("delete_slide", json.dumps({"slide_number": 3}), h)
        self.assertEqual(len(h.deck.slides), 2)

    def test_rendered_pixel_audit_records_fresh_visual_evidence(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"WORKSPACE": tmp}):
            rendered = Path(tmp) / "rendered"
            rendered.mkdir()
            image = Image.new("RGB", (640, 360), "white")
            draw = ImageDraw.Draw(image)
            draw.rectangle((100, 80, 540, 280), fill=(30, 60, 100))
            image.save(rendered / "slide-1.png")
            h = DummyHarness()
            report = dispatch("inspect_rendered_deck", json.dumps({"output_dir": "rendered"}), h)
            self.assertIn("audit passed", report)
            self.assertEqual(h.state.fresh_evidence()[0].kind, "ppt_visual")

    def test_every_layout_mutation_invalidates_evidence(self):
        h = DummyHarness()
        dispatch("new_deck", json.dumps({"title": "One"}), h)
        dispatch("ppt_verify", "{}", h)
        verified_epoch = h.state.mutation_epoch
        self.assertTrue(h.state.fresh_evidence())
        dispatch("add_slide", json.dumps({"title": "Two", "bullets": ["new"]}), h)
        self.assertGreater(h.state.mutation_epoch, verified_epoch)
        self.assertFalse(h.state.fresh_evidence())

    def test_verify_checks_non_text_shapes_for_boundary_crossing(self):
        h = DummyHarness()
        dispatch("new_deck", json.dumps({"title": "Boundary"}), h)
        slide = h.deck.slides[0]
        shape = slide.shapes.add_shape(1, 0, 0, 100000, 100000)
        shape.left = h.deck.slide_width - 100000
        shape.width = 200000
        report = dispatch("ppt_verify", "{}", h)
        self.assertIn("crosses slide boundary", report)

    def test_mutation_registry_covers_all_stateful_ppt_operations(self):
        expected = {
            "new_deck", "add_slide", "add_two_column_slide", "add_metric_slide",
            "add_table_slide", "add_process_slide", "add_image_slide", "add_textbox",
            "replace_shape_text", "set_shape_geometry", "delete_shape", "delete_slide",
            "move_slide", "save_deck",
        }
        self.assertEqual(_PPT_MUTATORS, expected)


if __name__ == "__main__":
    unittest.main()
