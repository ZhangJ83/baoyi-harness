# PPTBench blinded review rubric

This rubric is used only after deterministic artifact checks pass. Reviewers
must see anonymized artifact IDs and must not know which system produced them.

Score each dimension from 1 (poor) to 5 (excellent):

| Dimension | Question |
|---|---|
| Content fidelity | Does the deck preserve the requested topic and required facts? |
| Hierarchy | Is the main message obvious on each slide? |
| Layout | Are alignment, spacing, balance, and grouping intentional? |
| Typography | Are font sizes, line lengths, bilingual text, and contrast readable? |
| Visual consistency | Do theme, colors, and component styles remain coherent? |
| Density | Is information compact without clipping or overwhelming the viewer? |
| Edit fidelity | For modification tasks, is the requested change made without unrelated damage? |

## Protocol

1. Reject artifacts that fail deterministic open/slide/content checks.
2. Randomize and anonymize system labels before review.
3. Use two independent reviewers per pair; collect a 1–5 score per dimension.
4. Record disagreements and resolve only after the blind pass is locked.
5. Report mean, median, inter-rater agreement, and confidence intervals.

Human scores must remain separate from the deterministic structural score and
must not be used to claim official benchmark performance without a published
task split and scorer version.
