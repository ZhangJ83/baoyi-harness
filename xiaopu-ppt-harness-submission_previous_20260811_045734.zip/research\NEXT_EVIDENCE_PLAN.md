# Next evidence plan toward a publication-scale claim

This plan preserves the current fail-closed claim boundary. It is ordered by
information gain and dependency, not by presentation polish.

| Priority | Evidence slice | Minimum design | Success / promotion rule | Current blocker |
|---|---|---|---|---|
| P0 | Valid matched harness comparison | 12--18 predeclared task IDs, same model/provider, identical task/step/tool/token caps, one attempt, paired outcomes | Report task-level delta, bootstrap CI, exact McNemar test, cost and latency; no superiority unless all preregistered gates pass | Provider credential and parity-capable adapters |
| P1 | Real-task controller ablation | Xiaopu direct loop vs always-verify vs CEGAR-H, identical tasks and model, fixed budget | Report paired resolution, verification count, tokens, wall-clock, and failure modes; causal claim only if controller improves outcome or cost at fixed outcome | Same valid task slice and budget ledger |
| P2 | Model-generated PPT slice | Frozen prompts and source materials; generate/edit decks; render via pinned renderer | Blind structural + semantic + visual rubric, inter-rater agreement, full artifact traces; controlled demo must remain separate | PPT task set, renderer and reviewers |
| P3 | Multi-instance SWE check | At least 10 score-eligible instances before any non-pilot wording | Official evaluator, patch validity, test outcomes, token/latency ledger | Compute and official dependency stability |
| P4 | Independent review | Send manuscript plus evidence manifest to a reviewer with no implementation role | Dated report with explicit strengths, weaknesses, and recommendation | External reviewer access |

## Stop conditions

- Any infrastructure-invalid trial is excluded from the denominator and triggers
  protocol repair before new model calls.
- A missing budget ledger blocks competitor claims even if task outcomes exist.
- A failed minimum-n or confidence gate downgrades the wording; it does not
  motivate selective task removal.
- PPT pixel checks remain reliability gates, never substitutes for semantic or
  aesthetic human/vision assessment.

The machine-readable objective gate remains authoritative until every required
row is closed.
