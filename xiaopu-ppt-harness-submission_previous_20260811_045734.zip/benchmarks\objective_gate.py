"""Requirement-by-requirement gate for the full research objective.

This is intentionally stricter than the pilot claim gate. It reports exactly
which requested deliverables are proven by durable artifacts and refuses to
promote slices, fixtures, or local reviews to final evidence.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def read_json(path: Path, default: dict | list | None = None):
    if not path.is_file():
        return {} if default is None else default
    return json.loads(path.read_text(encoding="utf-8"))


def build(root: Path) -> dict:
    audit = read_json(root / "workspace/results/completion_audit_current.json")
    claim = read_json(root / "workspace/results/claims_gate_current.json")
    protocol = read_json(root / "benchmarks/official_matched_protocol.json")
    budget_parity = bool(protocol.get("budget_enforcement", {}).get("budget_parity_verified"))
    matrix = read_json(root / "research/paper_experiment_matrix.json", {"experiments": []})
    exhaustive = read_json(root / "workspace/results/exhaustive_theory_check.json")
    paired_ablation = root / "workspace/results/paired_synthetic_ablation.json"
    external_reports = list((root / "research/review").glob("external*review*.md"))
    checks = {
        "infrastructure_readiness": {
            "achieved": audit.get("checks", {}).get("infrastructure_readiness", {}).get("status") == "ready",
            "evidence": audit.get("checks", {}).get("infrastructure_readiness", {}).get("evidence"),
            "required": "post-reboot pagefile and virtual-memory readiness probe passes",
        },
        "official_terminal_bench_full": {
            "achieved": audit.get("checks", {}).get("official_terminal_bench", {}).get("status") == "full_benchmark",
            "evidence": audit.get("checks", {}).get("official_terminal_bench", {}).get("evidence"),
            "required": "all pinned official task IDs scored by the official scorer",
        },
        "official_swe_bench_verified_full": {
            "achieved": audit.get("checks", {}).get("official_swe_bench_verified", {}).get("status") == "official_full_benchmark",
            "evidence": audit.get("checks", {}).get("official_swe_bench_verified", {}).get("evidence"),
            "required": "full declared SWE-bench Verified universe scored by the official evaluator",
        },
        "matched_claude_codex_protocol": {
            "achieved": bool(claim.get("claim_allowed")) and budget_parity,
            "evidence": "workspace/results/claims_gate_current.json; benchmarks/official_matched_protocol.json",
            "required": "identical task IDs/results plus verified token/tool/step budget enforcement",
        },
        "competitor_superiority_statistics": {
            "achieved": bool(claim.get("superiority_supported")),
            "evidence": "workspace/results/claims_gate_current.json",
            "required": "paired CI, exact test, and preregistered minimum n all pass",
        },
        "complete_component_ablations": {
            "achieved": paired_ablation.is_file() and any(
                e.get("exp_id") == "E8" and e.get("status") == "completed"
                for e in matrix.get("experiments", [])
            ),
            "evidence": str(paired_ablation),
            "required": "same-stream component ablations with confidence intervals",
        },
        "theory_and_falsification": {
            "achieved": (
                (root / "research/THEORY_APPENDIX.md").is_file()
                and exhaustive.get("binary", {}).get("violations") == 0
                and exhaustive.get("multi_action", {}).get("violations") == 0
            ),
            "evidence": "research/THEORY_APPENDIX.md; workspace/results/exhaustive_theory_check.json",
            "required": "explicit assumptions, derivations, and falsification checks",
        },
        "model_generated_ppt_evaluation": {
            "achieved": False,
            "evidence": "workspace/results/pptbench_structural_smoke_latest.json",
            "required": "frozen model-generated decks with render-aware scoring",
        },
        "external_independent_review": {
            "achieved": any("external=true" in p.read_text(encoding="utf-8").lower() for p in external_reports),
            "evidence": [str(p) for p in external_reports],
            "required": "dated independent report, not local self-review or a review packet",
        },
    }
    return {
        "kind": "xiaopu_full_objective_gate",
        "objective_complete": all(item["achieved"] for item in checks.values()),
        "checks": checks,
        "claim_boundary": "a false check is an evidence gap, not a runtime failure",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = build(args.root.resolve())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
