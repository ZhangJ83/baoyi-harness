# Xiaopu PPT harness submission manifest

## Start here

1. `docs/competitive-harness-ppt.md` — Claude Code, Cursor, and Codex mechanism study; facts and inference are separated.
2. `research/PPT_HARNESS_FINAL_REPORT.md` — implemented architecture, verified results, limitations, and reproduction.
3. `docs/interview-story-v2.md` — one-minute and step-by-step interview narrative.
4. `research/PPT_HARNESS_EVAL_CONTRACT.md` — frozen evaluation questions, baselines, metrics, and promotion gate.
5. `research/BEST_PAPER_GAP_MATRIX.md` — strict requirement-by-requirement audit and closure plan.

## Implementation

The paper draft also has a static QA record at
`research/PAPER_STATIC_QA.md`.

The first authorized external slice and its infrastructure/agent separation
are documented in `research/FAILURE_ANALYSIS_20260811.md`.
`benchmarks/terminal_bench_preflight.ps1` records whether the official images
are cached before spending provider tokens.

- `agent/harness.py` — provider-neutral tool loop, budgets, compaction, hooks, and completion checks.
- `agent/state.py` — task, mutation epoch, and evidence state.
- `agent/tools/ppt_tools.py` — PPT create/edit/layout/render/verify tools.
- `agent/tools/registry.py` — tool schemas, validation, routing, and centralized PPT mutation tracking.
- `agent/builtin_skills/powerpoint/SKILL.md` — office-document workflow.

## Verification

- `tests/test_ppt.py` — creation, modification, layout, evidence invalidation, and pixel-audit tests.
- `tests/test_ppt_score.py` and `tests/test_evidence_validator.py` — scoring and evidence gates.
- `experiments/ppt_harness_demo.py` — reproducible end-to-end demonstration.
- `workspace/results/ppt_harness_demo/ppt-harness-demo.pptx` — four-slide output artifact.
- `workspace/results/ppt_harness_demo/demo-report.json` — tool trace and stale-evidence intervention.
- `workspace/results/ppt_harness_demo/final-evidence-report.json` — unified trace, deck hash, PNG count, montage, and rendered audit.
- `benchmarks/completion_audit.py` and `workspace/results/completion_audit_current.json` — machine-readable promotion boundary; controlled rendered demo is tracked separately from full PPTBench.

## Final verified status

Mutation-surface audit: `benchmarks/audit_ppt_mutation_coverage.py` reports 14
registered PPT mutators, each covered by a direct ledger write or the central
dispatch fallback. The report is stored at
`workspace/results/ppt_mutation_coverage.json`.

Claim-evidence audit: `benchmarks/validate_claim_evidence_map.py` reports all
4 paper claims with existing evidence paths and explicit caveats; its result
is `workspace/results/claim_evidence_map_validation.json`.

Integrity manifest: `benchmarks/build_evidence_manifest.py` records SHA-256
digests for the paper draft, claim map, gap matrix, and core evidence outputs;
the current manifest is `workspace/results/evidence_manifest.json`.

Full-objective gate: `workspace/results/objective_gate_current.json` is the
authoritative requirement audit. It currently reports `objective_complete=false`;
infrastructure, ablations, and theory checks pass, while publication-scale
benchmark, PPT, parity, and independent-review requirements remain open.

The archive root contains the source trees (`agent/`, `benchmarks/`,
`docs/`, `experiments/`, `research/`, and `tests/`). Generated evidence is
stored at the archive root under `completion_audit_current.json`,
`evidence_validation_current.json`, and `ppt_harness_demo/` because the
Windows archive command flattens explicitly selected generated paths.

- full lightweight regression: 74 passed, 5 skipped (five terminal adapter tests require the official host dependency);
- official Terminal-Bench environment: 7 focused adapter tests passed, including failure-path ledger preservation;
- compile gate: `python -m compileall -q agent benchmarks experiments` passed;
- demo deterministic score: 1.0;
- post-verification edit rejects old evidence: true;
- final demo rendered visual evidence: four PNGs, PDF, montage, and a passing deterministic pixel audit are present;
- edge-content warnings are informational for intentional full-bleed backgrounds;
- no competitor-superiority or broad aesthetic-quality claim is made.

ICLR alignment audit: `research/ICLR_REVIEW_ALIGNMENT.md` maps the manuscript
to the four core reviewer questions and records required wording and evidence
boundaries.

Rendered visual review: `research/PPT_VISUAL_REVIEW.md` records the direct
inspection of the four-slide montage after the deterministic pixel audit.

Archive verification: `benchmarks/verify_submission_archive.py` checks required
source, research, and flattened evidence paths in the final zip; the latest
result is `workspace/results/submission_archive_verification.json` with
`valid=true`.

Next evidence plan: `research/NEXT_EVIDENCE_PLAN.md` orders the remaining
publication-scale experiments by dependency and information gain.

Continuous goal charter: `research/CONTINUOUS_OPTIMIZATION_GOAL.md` defines the
iteration loop, priority frontier, non-negotiable claim gates, and completion
condition for ongoing Best-Paper-level optimization.

Provider preflight: `benchmarks/provider_preflight.ps1` checks credential
presence, Docker Engine, and pinned image cache before any model-backed run;
the current report is `workspace/results/provider_preflight.json`.

Fresh synthetic ablation: `experiments/paired_synthetic_ablation.py` was
rerun with 20 seeds × 2,000 tasks per seed; output is
`workspace/results/paired_synthetic_ablation_latest.json` and remains
synthetic-only evidence.

Offline real-trace sensitivity: `benchmarks/analyze_budget_sensitivity.py`
compares singleton and aggregate executions of the same three tasks. The
result, `workspace/results/offline_budget_sensitivity_20260811.json`, records a
3/3 to 1/3 regression and missing ledgers on truncated aggregate trials; it is
descriptive offline evidence, not a causal or official score.

Strict budget parity: `benchmarks/verify_budget_parity.py` now checks result-
ledger token agreement, caps, tool/step usage, wall time, duplicates, and
cross-system task-set parity. The current historical pilot correctly fails at
`workspace/results/budget_parity_current.json` because all per-task ledgers are
missing. `benchmarks/claim_gate.py` now consumes that report as a required
input and independently checks eligibility plus exact task-ID alignment; the
current `workspace/results/claims_gate_current.json` therefore rejects a
superiority claim even before the sample-size and significance failures are
considered.
