"""PPT tools: build, edit, verify a deck with python-pptx.

Deck state lives on the harness (`h.deck`), so tools compose across calls.
Visual layout: a minimal editorial theme — title band, low-contrast body,
an accent underline — built from plain shapes (no templates / no external assets).
"""
import math
import platform
import shutil
import subprocess
from typing import Any, Callable

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

Schema = dict[str, Any]

# --- theme ---
_PRIMARY = RGBColor(0x1F, 0x38, 0x64)   # deep navy
_ACCENT = RGBColor(0xF0, 0x9A, 0x1A)    # amber
_TEXT = RGBColor(0x2B, 0x2B, 0x2B)
_MUTED = RGBColor(0x87, 0x87, 0x87)
_BG = RGBColor(0xFB, 0xFA, 0xF7)        # warm paper
_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
_HEAD = RGBColor(0x25, 0x47, 0x7C)      # lighter navy for content titles

_W = 13.333
_H = 7.5


def _schema(name: str, description: str, params: dict[str, dict], required: list[str]):
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {"type": "object", "properties": params, "required": required},
        },
    }


def _deck(h: Any) -> Presentation:
    if getattr(h, "deck", None) is None:
        h.deck = Presentation()
        h.deck.slide_width = Inches(_W)
        h.deck.slide_height = Inches(_H)
    return h.deck


def _open_deck(h, path: str) -> str:
    from .. import config
    from ..permissions import path_within
    root = config.sandbox_root()
    source = (root / path).resolve()
    if not path_within(root, source):
        raise PermissionError("presentation path escapes workspace")
    if not source.exists():
        raise FileNotFoundError(path)
    h.deck = Presentation(str(source))
    return f"opened {path}: {len(h.deck.slides)} slides, {h.deck.slide_width / 914400:.2f}x{h.deck.slide_height / 914400:.2f}in"


def _blank_slide(prs: Presentation):
    return prs.slides.add_slide(prs.slide_layouts[6])


def _rect(slide, x: float, y: float, w: float, h: float, fill, line=None) -> "Shape":
    """Full-bleed helper: plain rectangle with a solid fill."""
    sp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    sp.fill.solid()
    sp.fill.fore_color.rgb = fill
    if line is None:
        sp.line.fill.background()
    else:
        sp.line.color.rgb = line
        sp.line.width = Pt(1)
    sp.shadow.inherit = False
    return sp


def _style_run(run, size: int, bold: bool, color: RGBColor) -> None:
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = "Microsoft YaHei"


def _fit_lines(tf, lines, size: int, bold: bool, color: RGBColor, space: float = 1.25) -> None:
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = 0
    tf.margin_top = 0
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.line_spacing = space
        run = p.add_run()
        run.text = line
        _style_run(run, size, bold, color)


def _put_lines(tf, text: str, size: int, bold: bool, color: RGBColor = _TEXT) -> None:
    _fit_lines(tf, text.split("\n"), size, bold, color)


def _new_deck(h, title: str, subtitle: str) -> str:
    prs = _deck(h)
    s = _blank_slide(prs)
    # warm paper background
    _rect(s, 0, 0, _W, _H, _BG)
    # left accent bar
    _rect(s, 0, 0, 0.25, _H, _ACCENT)
    # eyebrow
    tb = s.shapes.add_textbox(Inches(1.1), Inches(1.3), Inches(11), Inches(0.5))
    _fit_lines(tb.text_frame, ["P R E S E N T A T I O N"], 15, True, _ACCENT)
    # title (auto-shrink long titles)
    size = 44 if len(title) <= 16 else 36 if len(title) <= 24 else 30
    tb = s.shapes.add_textbox(Inches(1.1), Inches(2.1), Inches(11), Inches(2.4))
    _fit_lines(tb.text_frame, [title], size, True, _PRIMARY)
    # accent underline
    _rect(s, 1.15, 4.35, 1.4, 0.06, _ACCENT)
    if subtitle:
        tb = s.shapes.add_textbox(Inches(1.1), Inches(4.6), Inches(11), Inches(1.2))
        _fit_lines(tb.text_frame, subtitle.split("\n"), 18, False, _MUTED)
    return "new deck created: 16:9, one cover slide."


def _content_slide(h, title: str, bullets: list[str], size: int) -> str:
    prs = _deck(h)
    s = _blank_slide(prs)
    _rect(s, 0, 0, _W, _H, _BG)
    # header band
    _rect(s, 0, 0, _W, 1.1, _HEAD)
    _rect(s, 0, 1.1, _W, 0.07, _ACCENT)
    tb = s.shapes.add_textbox(Inches(0.55), Inches(0.12), Inches(12.2), Inches(0.9))
    _put_lines(tb.text_frame, title, 26, True, _WHITE)
    if bullets:
        tb2 = s.shapes.add_textbox(Inches(0.9), Inches(1.7), Inches(11.5), Inches(5.2))
        body = [f"•  {b}" for b in bullets]
        _fit_lines(tb2.text_frame, body, size, False, _TEXT)
    return f"added slide {len(prs.slides)}: '{title}' ({len(bullets)} bullets)"


def _two_column(h, title: str, left_title: str, left: list[str], right_title: str, right: list[str]) -> str:
    prs = _deck(h)
    s = _blank_slide(prs)
    _rect(s, 0, 0, _W, _H, _BG)
    _rect(s, 0, 0, _W, 1.1, _HEAD)
    _rect(s, 0, 1.1, _W, 0.07, _ACCENT)
    title_box = s.shapes.add_textbox(Inches(0.55), Inches(0.12), Inches(12.2), Inches(0.9))
    _put_lines(title_box.text_frame, title, 26, True, _WHITE)
    for x, heading, bullets in ((0.7, left_title, left), (6.85, right_title, right)):
        card = _rect(s, x, 1.6, 5.75, 5.1, _WHITE, RGBColor(0xDD, 0xDD, 0xD8))
        heading_box = s.shapes.add_textbox(Inches(x + 0.35), Inches(1.9), Inches(5.05), Inches(0.65))
        _put_lines(heading_box.text_frame, heading, 20, True, _PRIMARY)
        body = s.shapes.add_textbox(Inches(x + 0.35), Inches(2.75), Inches(5.05), Inches(3.55))
        _fit_lines(body.text_frame, [f"•  {item}" for item in bullets], 17, False, _TEXT, 1.2)
    return f"added two-column slide {len(prs.slides)}: '{title}'"


def _metric_slide(h, title: str, metrics: list[dict], takeaway: str = "") -> str:
    if not 1 <= len(metrics) <= 4:
        raise ValueError("metric slide requires 1-4 metrics")
    prs = _deck(h)
    s = _blank_slide(prs)
    _rect(s, 0, 0, _W, _H, _PRIMARY)
    title_box = s.shapes.add_textbox(Inches(0.75), Inches(0.55), Inches(11.8), Inches(0.75))
    _put_lines(title_box.text_frame, title, 28, True, _WHITE)
    gap = 0.25
    card_w = (11.85 - gap * (len(metrics) - 1)) / len(metrics)
    for index, metric in enumerate(metrics):
        x = 0.75 + index * (card_w + gap)
        _rect(s, x, 1.75, card_w, 3.45, _WHITE)
        value_box = s.shapes.add_textbox(Inches(x + 0.25), Inches(2.15), Inches(card_w - 0.5), Inches(1.05))
        _put_lines(value_box.text_frame, str(metric.get("value", "—")), 32, True, _ACCENT)
        label_box = s.shapes.add_textbox(Inches(x + 0.25), Inches(3.3), Inches(card_w - 0.5), Inches(0.7))
        _put_lines(label_box.text_frame, str(metric.get("label", "")), 17, True, _PRIMARY)
        detail_box = s.shapes.add_textbox(Inches(x + 0.25), Inches(4.15), Inches(card_w - 0.5), Inches(0.7))
        _put_lines(detail_box.text_frame, str(metric.get("detail", "")), 13, False, _MUTED)
    if takeaway:
        note = s.shapes.add_textbox(Inches(0.85), Inches(5.75), Inches(11.65), Inches(0.85))
        _put_lines(note.text_frame, takeaway, 18, False, _WHITE)
    return f"added metric slide {len(prs.slides)}: '{title}'"


def _table_slide(h, title: str, columns: list[str], rows: list[list[str]]) -> str:
    if not columns or len(columns) > 6:
        raise ValueError("table requires 1-6 columns")
    if not rows or len(rows) > 10:
        raise ValueError("table requires 1-10 rows")
    if any(len(row) != len(columns) for row in rows):
        raise ValueError("every row must match the column count")
    prs = _deck(h)
    s = _blank_slide(prs)
    _rect(s, 0, 0, _W, _H, _BG)
    _rect(s, 0, 0, _W, 1.1, _HEAD)
    _rect(s, 0, 1.1, _W, 0.07, _ACCENT)
    title_box = s.shapes.add_textbox(Inches(0.55), Inches(0.12), Inches(12.2), Inches(0.9))
    _put_lines(title_box.text_frame, title, 26, True, _WHITE)
    table_shape = s.shapes.add_table(len(rows) + 1, len(columns), Inches(0.65), Inches(1.55), Inches(12.0), Inches(5.35))
    table = table_shape.table
    for col_index, label in enumerate(columns):
        cell = table.cell(0, col_index)
        cell.text = label
        cell.fill.solid()
        cell.fill.fore_color.rgb = _PRIMARY
    for row_index, row in enumerate(rows, 1):
        for col_index, value in enumerate(row):
            cell = table.cell(row_index, col_index)
            cell.text = str(value)
            cell.fill.solid()
            cell.fill.fore_color.rgb = _WHITE if row_index % 2 else RGBColor(0xF1, 0xF0, 0xEC)
    for table_row_index, row in enumerate(table.rows):
        for cell in row.cells:
            cell.margin_left = Inches(0.1)
            cell.margin_right = Inches(0.1)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            for paragraph in cell.text_frame.paragraphs:
                paragraph.alignment = PP_ALIGN.LEFT
                for run in paragraph.runs:
                    _style_run(run, 13, table_row_index == 0, _WHITE if table_row_index == 0 else _TEXT)
    return f"added table slide {len(prs.slides)}: '{title}' ({len(rows)} rows)"


def _process_slide(h, title: str, steps: list[dict], takeaway: str = "") -> str:
    if not 3 <= len(steps) <= 5:
        raise ValueError("process slide requires 3-5 steps")
    prs = _deck(h)
    s = _blank_slide(prs)
    _rect(s, 0, 0, _W, _H, _BG)
    title_box = s.shapes.add_textbox(Inches(0.7), Inches(0.45), Inches(12), Inches(0.7))
    _put_lines(title_box.text_frame, title, 28, True, _PRIMARY)
    start_x, y, total_w = 0.75, 1.65, 11.85
    gap = 0.18
    step_w = (total_w - gap * (len(steps) - 1)) / len(steps)
    for index, step in enumerate(steps, 1):
        x = start_x + (index - 1) * (step_w + gap)
        _rect(s, x, y, step_w, 3.7, _WHITE, RGBColor(0xDD, 0xDD, 0xD8))
        badge = _rect(s, x + 0.25, y + 0.3, 0.52, 0.52, _ACCENT)
        badge.text_frame.clear()
        badge.text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        paragraph = badge.text_frame.paragraphs[0]
        paragraph.alignment = PP_ALIGN.CENTER
        run = paragraph.add_run()
        run.text = str(index)
        _style_run(run, 14, True, _WHITE)
        heading = s.shapes.add_textbox(Inches(x + 0.25), Inches(y + 1.15), Inches(step_w - 0.5), Inches(0.75))
        _put_lines(heading.text_frame, str(step.get("title", "")), 19, True, _PRIMARY)
        detail = s.shapes.add_textbox(Inches(x + 0.25), Inches(y + 2.05), Inches(step_w - 0.5), Inches(1.15))
        _put_lines(detail.text_frame, str(step.get("detail", "")), 14, False, _TEXT)
    if takeaway:
        note = s.shapes.add_textbox(Inches(0.85), Inches(5.85), Inches(11.6), Inches(0.75))
        _put_lines(note.text_frame, takeaway, 18, True, _PRIMARY)
    return f"added process slide {len(prs.slides)}: '{title}'"


def _image_slide(h, title: str, image_path: str, caption: str = "") -> str:
    from .. import config
    from ..permissions import path_within
    root = config.sandbox_root().resolve()
    source = (root / image_path).resolve()
    if not path_within(root, source) or not source.is_file():
        raise FileNotFoundError(image_path)
    prs = _deck(h)
    s = _blank_slide(prs)
    _rect(s, 0, 0, _W, _H, _BG)
    title_box = s.shapes.add_textbox(Inches(0.7), Inches(0.35), Inches(12), Inches(0.7))
    _put_lines(title_box.text_frame, title, 27, True, _PRIMARY)
    from PIL import Image
    with Image.open(source) as image:
        ratio = image.width / image.height
    max_w, max_h = 11.7, 5.35
    width = min(max_w, max_h * ratio)
    height = width / ratio
    x = (_W - width) / 2
    y = 1.25 + (max_h - height) / 2
    s.shapes.add_picture(str(source), Inches(x), Inches(y), width=Inches(width), height=Inches(height))
    if caption:
        caption_box = s.shapes.add_textbox(Inches(0.9), Inches(6.8), Inches(11.5), Inches(0.4))
        _put_lines(caption_box.text_frame, caption, 11, False, _MUTED)
    return f"added image slide {len(prs.slides)}: '{title}'"


def _shape_inventory(h, slide_number: int | None = None) -> str:
    if getattr(h, "deck", None) is None:
        return "no deck yet."
    selected = range(len(h.deck.slides)) if slide_number is None else [slide_number - 1]
    lines = []
    for index in selected:
        if index < 0 or index >= len(h.deck.slides):
            raise IndexError(f"slide number out of range: {slide_number}")
        for shape in h.deck.slides[index].shapes:
            text = shape.text.strip().replace("\n", " | ")[:100] if getattr(shape, "has_text_frame", False) else ""
            lines.append(
                f"slide={index + 1} id={shape.shape_id} name={shape.name!r} "
                f"box=({shape.left/914400:.2f},{shape.top/914400:.2f},{shape.width/914400:.2f},{shape.height/914400:.2f}) text={text!r}"
            )
    return "\n".join(lines)


def _replace_text(h, slide_number: int, shape_id: int, text: str) -> str:
    if getattr(h, "deck", None) is None:
        raise ValueError("no deck loaded")
    if slide_number < 1 or slide_number > len(h.deck.slides):
        raise IndexError("slide number out of range")
    for shape in h.deck.slides[slide_number - 1].shapes:
        if shape.shape_id == shape_id:
            if not shape.has_text_frame:
                raise TypeError("target shape has no text frame")
            style = None
            for paragraph in shape.text_frame.paragraphs:
                if paragraph.runs:
                    run = paragraph.runs[0]
                    try:
                        rgb = run.font.color.rgb
                    except (AttributeError, ValueError):
                        rgb = None
                    style = (run.font.size, run.font.bold, run.font.name, rgb)
                    break
            shape.text_frame.text = text
            if style and shape.text_frame.paragraphs[0].runs:
                run = shape.text_frame.paragraphs[0].runs[0]
                run.font.size, run.font.bold, run.font.name = style[:3]
                if style[3] is not None:
                    run.font.color.rgb = style[3]
            h.state.record_change(f"deck:slide:{slide_number}:shape:{shape_id}:text")
            return f"updated slide {slide_number} shape {shape_id}"
    raise KeyError(f"shape id not found: {shape_id}")


def _find_shape(h, slide_number: int, shape_id: int):
    if getattr(h, "deck", None) is None:
        raise ValueError("no deck loaded")
    if slide_number < 1 or slide_number > len(h.deck.slides):
        raise IndexError("slide number out of range")
    slide = h.deck.slides[slide_number - 1]
    for shape in slide.shapes:
        if shape.shape_id == shape_id:
            return slide, shape
    raise KeyError(f"shape id not found: {shape_id}")


def _set_shape_geometry(h, slide_number: int, shape_id: int, x: float, y: float, w: float, height: float) -> str:
    if min(x, y) < 0 or w <= 0 or height <= 0:
        raise ValueError("shape geometry must be non-negative with positive width and height")
    if x + w > _W or y + height > _H:
        raise ValueError("shape geometry crosses the 16:9 slide boundary")
    _, shape = _find_shape(h, slide_number, shape_id)
    shape.left, shape.top = Inches(x), Inches(y)
    shape.width, shape.height = Inches(w), Inches(height)
    h.state.record_change(f"deck:slide:{slide_number}:shape:{shape_id}:geometry")
    return f"moved/resized slide {slide_number} shape {shape_id} -> ({x:.2f},{y:.2f},{w:.2f},{height:.2f})"


def _delete_shape(h, slide_number: int, shape_id: int) -> str:
    _, shape = _find_shape(h, slide_number, shape_id)
    shape._element.getparent().remove(shape._element)
    h.state.record_change(f"deck:slide:{slide_number}:shape:{shape_id}:deleted")
    return f"deleted slide {slide_number} shape {shape_id}"


def _delete_slide(h, slide_number: int) -> str:
    if getattr(h, "deck", None) is None:
        raise ValueError("no deck loaded")
    if slide_number < 1 or slide_number > len(h.deck.slides):
        raise IndexError("slide number out of range")
    slide_id = h.deck.slides._sldIdLst[slide_number - 1]
    relationship_id = slide_id.rId
    h.deck.part.drop_rel(relationship_id)
    h.deck.slides._sldIdLst.remove(slide_id)
    h.state.record_change(f"deck:slide:{slide_number}:deleted")
    return f"deleted slide {slide_number}; {len(h.deck.slides)} slides remain"


def _move_slide(h, slide_number: int, new_position: int) -> str:
    if getattr(h, "deck", None) is None:
        raise ValueError("no deck loaded")
    count = len(h.deck.slides)
    if slide_number < 1 or slide_number > count or new_position < 1 or new_position > count:
        raise IndexError("slide number or destination out of range")
    slide_id = h.deck.slides._sldIdLst[slide_number - 1]
    h.deck.slides._sldIdLst.remove(slide_id)
    h.deck.slides._sldIdLst.insert(new_position - 1, slide_id)
    h.state.record_change(f"deck:slide:{slide_number}:moved:{new_position}")
    return f"moved slide {slide_number} to position {new_position}"


def _render(h, path: str, output_dir: str = "rendered") -> str:
    from .. import config
    from ..permissions import path_within

    root = config.sandbox_root().resolve()
    source = (root / path).resolve()
    target = (root / output_dir).resolve()
    if not path_within(root, source) or not path_within(root, target):
        raise PermissionError("render path escapes workspace")
    if not source.is_file():
        raise FileNotFoundError(path)
    target.mkdir(parents=True, exist_ok=True)
    for stale in target.iterdir():
        if stale.is_file() and stale.suffix.lower() == ".png":
            stale.unlink()
    if platform.system() == "Windows":
        try:
            import win32com.client
        except ImportError as exc:
            raise RuntimeError("pywin32 is required for PowerPoint rendering") from exc

        try:
            app = win32com.client.DispatchEx("PowerPoint.Application")
        except Exception as exc:
            # COM can be installed but unavailable in a headless/service
            # session. Surface a stable diagnostic so the harness can report a
            # renderer limitation instead of an opaque pywintypes traceback.
            raise RuntimeError(
                "PowerPoint COM renderer unavailable in this session; "
                "use an interactive Windows session or LibreOffice fallback"
            ) from exc
        presentation = None
        try:
            presentation = app.Presentations.Open(str(source), ReadOnly=True, Untitled=False, WithWindow=False)
            pdf = target / f"{source.stem}.pdf"
            presentation.SaveCopyAs(str(pdf), 32)
            presentation.Export(str(target), "PNG")
        finally:
            if presentation is not None:
                presentation.Close()
            app.Quit()
    else:
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        pdftoppm = shutil.which("pdftoppm")
        if not soffice or not pdftoppm:
            raise RuntimeError("Linux PPT rendering requires soffice/libreoffice and pdftoppm")
        pdf = target / f"{source.stem}.pdf"
        convert = subprocess.run(
            [soffice, "--headless", "--convert-to", "pdf", "--outdir", str(target), str(source)],
            capture_output=True, text=True, timeout=120,
        )
        if convert.returncode != 0 or not pdf.exists():
            raise RuntimeError(f"LibreOffice conversion failed: {(convert.stderr or convert.stdout).strip()}")
        raster = subprocess.run(
            [pdftoppm, "-png", "-r", "120", str(pdf), str(target / "slide")],
            capture_output=True, text=True, timeout=120,
        )
        if raster.returncode != 0:
            raise RuntimeError(f"pdftoppm conversion failed: {(raster.stderr or raster.stdout).strip()}")
    images = sorted({image.resolve() for image in target.iterdir() if image.is_file() and image.suffix.lower() == ".png" and image.name.lower() != "montage.png"})
    pdf = target / f"{source.stem}.pdf"
    if not pdf.is_file() or pdf.stat().st_size == 0:
        raise RuntimeError("renderer produced no PDF")
    if not images:
        raise RuntimeError("renderer produced no PNG slides")
    from PIL import Image, ImageDraw
    opened = [Image.open(image).convert("RGB") for image in images]
    try:
        thumb_w = 640
        thumbs = []
        for index, slide_image in enumerate(opened, 1):
            thumb_h = round(slide_image.height * thumb_w / slide_image.width)
            thumb = slide_image.resize((thumb_w, thumb_h))
            canvas = Image.new("RGB", (thumb_w, thumb_h + 36), "white")
            canvas.paste(thumb, (0, 36))
            ImageDraw.Draw(canvas).text((12, 10), f"Slide {index}", fill=(35, 35, 35))
            thumbs.append(canvas)
        columns = 2
        rows = math.ceil(len(thumbs) / columns)
        cell_h = max(thumb.height for thumb in thumbs)
        montage = Image.new("RGB", (columns * thumb_w, rows * cell_h), (225, 225, 225))
        for index, thumb in enumerate(thumbs):
            montage.paste(thumb, ((index % columns) * thumb_w, (index // columns) * cell_h))
        montage_path = target / "montage.png"
        montage.save(montage_path)
    finally:
        for slide_image in opened:
            slide_image.close()
    h.state.record_evidence("ppt_render", f"ppt rendered: {len(images)} PNG slides from {path}")
    return "rendered slides:\n" + "\n".join(str(image.relative_to(root)) for image in images) + f"\nmontage: {montage_path.relative_to(root)}"


def _inspect_rendered(h, output_dir: str = "rendered") -> str:
    """Turn rendered pixels into auditable, deterministic visual evidence.

    This is intentionally a coarse gate, not an aesthetic judge. It catches
    blank renders and content pressed against the slide edge, while leaving
    semantic visual quality to a human or vision model review.
    """
    from PIL import Image, ImageStat
    from .. import config
    from ..permissions import path_within

    root = config.sandbox_root().resolve()
    target = (root / output_dir).resolve()
    if not path_within(root, target):
        raise PermissionError("render inspection path escapes workspace")
    images = sorted(path for path in target.glob("*.png") if path.name.lower() != "montage.png")
    if not images:
        raise FileNotFoundError("no rendered slide PNGs found")
    findings: list[str] = []
    warnings: list[str] = []
    rows: list[str] = []
    for index, path in enumerate(images, 1):
        with Image.open(path) as source:
            gray = source.convert("L")
            width, height = gray.size
            stat = ImageStat.Stat(gray)
            variance = stat.var[0]
            margin = max(2, round(min(width, height) * 0.015))
            pixels = gray.load()
            edge_dark = 0
            edge_total = 0
            for y in range(height):
                for x in range(width):
                    if x < margin or x >= width - margin or y < margin or y >= height - margin:
                        edge_total += 1
                        if pixels[x, y] < 235:
                            edge_dark += 1
            edge_ratio = edge_dark / max(1, edge_total)
            rows.append(f"slide {index}: variance={variance:.1f}, edge_content={edge_ratio:.3f}")
            if variance < 8:
                findings.append(f"slide {index}: probable blank/near-uniform render")
            # Full-bleed theme backgrounds and title bands are intentional in
            # presentation design. Keep this as a warning rather than a hard
            # failure; geometric clipping is already checked by ppt_verify.
            if edge_ratio > 0.30:
                warnings.append(f"slide {index}: full-bleed/edge content warning ({edge_ratio:.3f}); review if not intentional")
    if findings:
        return "Rendered visual audit findings:\n" + "\n".join(findings) + "\nMetrics:\n" + "\n".join(rows)
    h.state.record_evidence("ppt_visual", f"rendered visual audit passed: {len(images)} slides")
    warning_text = "\nWarnings:\n" + "\n".join(warnings) if warnings else ""
    return "Rendered visual audit passed.\n" + "\n".join(rows) + warning_text


def _add_box(h, box: dict) -> str:
    s = h.deck.slides[-1]
    tb = s.shapes.add_textbox(
        Inches(box["x"]), Inches(box["y"]), Inches(box["w"]), Inches(box["h"])
    )
    _fit_lines(tb.text_frame, str(box.get("text", "")).split("\n"), box.get("size", 18), box.get("bold", False), _TEXT)
    return "text box added."


def _box_from_kw(kw: dict) -> dict:
    box = dict(kw)
    box["h"] = kw["height"]
    return box


def _save(h, path: str | None) -> str:
    from pathlib import Path
    from .. import config
    root = config.sandbox_root()
    if path:
        p = Path(path)
        # tolerate an explicit "workspace/..." prefix from LLM args
        if not p.is_absolute() and p.parts and p.parts[0] in ("workspace", root.name):
            p = Path(*p.parts[1:])
        target = p if p.is_absolute() else root / p
    else:
        target = root / "deck.pptx"
    target.parent.mkdir(parents=True, exist_ok=True)
    prs = _deck(h)
    prs.save(str(target))
    try:
        h.state.record_change(str(target.relative_to(root)))
    except ValueError:
        h.state.record_change(str(target))
    return f"saved {len(prs.slides)} slides -> {target.name}"


def _deck_info(h) -> str:
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    if getattr(h, "deck", None) is None:
        return "no deck yet."
    lines = []
    for i, slide in enumerate(h.deck.slides, 1):
        texts = []
        for sh in slide.shapes:
            if sh.has_text_frame and sh.shape_type == MSO_SHAPE_TYPE.TEXT_BOX:
                t = (sh.text_frame.text or "").strip()
                if t:
                    texts.append(t.replace("\n", " | ")[:70])
        lines.append(f"  slide {i}: " + ("; ".join(texts) if texts else "(empty)"))
    return f"{len(h.deck.slides)} slides:\n" + "\n".join(lines)


def _verify(h) -> str:
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    if getattr(h, "deck", None) is None:
        return "no deck yet to verify."
    findings = []
    for i, slide in enumerate(h.deck.slides, 1):
        text_shapes = []
        for sh in slide.shapes:
            # skip background / decorative rectangles — only inspect real text boxes
            if sh.has_text_frame and sh.shape_type == MSO_SHAPE_TYPE.TEXT_BOX:
                text_shapes.append(sh)
                text = (sh.text_frame.text or "").strip()
                if not text:
                    findings.append(f"slide {i}: empty text box")
                    continue
                big = 18
                for p in sh.text_frame.paragraphs:
                    for r in p.runs:
                        if r.font.size:
                            big = max(big, r.font.size.pt)
                w_in = sh.width / 914400
                h_in = sh.height / 914400
                cpl = max(1, int(w_in * 96 / (big * 0.75)))
                lines = 0
                for ln in text.split("\n"):
                    lines += max(1, math.ceil(len(ln) / cpl))
                needed = lines * big * 0.62 / 72
                if needed > h_in * 0.95:
                    findings.append(f"slide {i}: overflow risk ~{needed:.2f}in in {h_in:.2f}in box")
            # Inspect every positioned shape, not only text boxes. Pictures,
            # charts, tables, and decorative shapes can also be clipped.
            if sh.left < 0 or sh.top < 0 or sh.left + sh.width > h.deck.slide_width or sh.top + sh.height > h.deck.slide_height:
                findings.append(f"slide {i}: shape {sh.shape_id} crosses slide boundary")
        for left_index, a in enumerate(text_shapes):
            for b in text_shapes[left_index + 1:]:
                overlap_w = min(a.left + a.width, b.left + b.width) - max(a.left, b.left)
                overlap_h = min(a.top + a.height, b.top + b.height) - max(a.top, b.top)
                if overlap_w > 0 and overlap_h > 0:
                    ratio = (overlap_w * overlap_h) / min(a.width * a.height, b.width * b.height)
                    if ratio > 0.15:
                        findings.append(f"slide {i}: text shapes {a.shape_id}/{b.shape_id} overlap {ratio:.0%}")
    if not findings:
        h.state.record_evidence("ppt_structural", f"ppt structural verification passed: {len(h.deck.slides)} slides")
        return "Verification: no structural issues found."
    return "Verification findings:\n" + "\n".join(findings)


def _make(name: str, description: str, params: dict[str, dict], required: list[str], fn: Callable):
    return (_schema(name, description, params, required), fn)


ppt_tools = [
    _make(
        "open_deck",
        "Load an existing .pptx from the workspace for inspection or modification.",
        {"path": {"type": "string"}},
        ["path"],
        lambda h, **kw: _open_deck(h, kw["path"]),
    ),
    _make(
        "new_deck",
        "Create a new empty PowerPoint deck (16:9) with a cover slide.",
        {"title": {"type": "string"}, "subtitle": {"type": "string"}},
        ["title"],
        lambda h, **kw: _new_deck(h, kw.get("title", "Untitled"), kw.get("subtitle", "")),
    ),
    _make(
        "add_slide",
        "Add a content slide with title and optional bullet list.",
        {
            "title": {"type": "string"},
            "bullets": {"type": "array", "items": {"type": "string"}},
            "size": {"type": "integer", "description": "bullet font size"},
        },
        ["title"],
        lambda h, **kw: _content_slide(h, kw.get("title", ""), kw.get("bullets") or [], kw.get("size", 18)),
    ),
    _make(
        "add_two_column_slide",
        "Add a comparison or paired-argument slide with two balanced cards.",
        {"title": {"type": "string"}, "left_title": {"type": "string"}, "left_bullets": {"type": "array", "items": {"type": "string"}}, "right_title": {"type": "string"}, "right_bullets": {"type": "array", "items": {"type": "string"}}},
        ["title", "left_title", "left_bullets", "right_title", "right_bullets"],
        lambda h, **kw: _two_column(h, kw["title"], kw["left_title"], kw["left_bullets"], kw["right_title"], kw["right_bullets"]),
    ),
    _make(
        "add_metric_slide",
        "Add a visual KPI slide with 1-4 metric cards and an optional takeaway.",
        {"title": {"type": "string"}, "metrics": {"type": "array", "minItems": 1, "maxItems": 4, "items": {"type": "object", "properties": {"value": {"type": "string"}, "label": {"type": "string"}, "detail": {"type": "string"}}, "required": ["value", "label"]}}, "takeaway": {"type": "string"}},
        ["title", "metrics"],
        lambda h, **kw: _metric_slide(h, kw["title"], kw["metrics"], kw.get("takeaway", "")),
    ),
    _make(
        "add_table_slide",
        "Add a styled table slide. Prefer for exact comparisons; keep at most 6 columns and 10 rows.",
        {"title": {"type": "string"}, "columns": {"type": "array", "items": {"type": "string"}}, "rows": {"type": "array", "items": {"type": "array", "items": {"type": "string"}}}},
        ["title", "columns", "rows"],
        lambda h, **kw: _table_slide(h, kw["title"], kw["columns"], kw["rows"]),
    ),
    _make(
        "add_process_slide",
        "Add a 3-5 step process, method, roadmap, or closing action slide.",
        {"title": {"type": "string"}, "steps": {"type": "array", "minItems": 3, "maxItems": 5, "items": {"type": "object", "properties": {"title": {"type": "string"}, "detail": {"type": "string"}}, "required": ["title", "detail"]}}, "takeaway": {"type": "string"}},
        ["title", "steps"],
        lambda h, **kw: _process_slide(h, kw["title"], kw["steps"], kw.get("takeaway", "")),
    ),
    _make(
        "add_image_slide",
        "Add a full-width image slide using an image already in the workspace.",
        {"title": {"type": "string"}, "image_path": {"type": "string"}, "caption": {"type": "string"}},
        ["title", "image_path"],
        lambda h, **kw: _image_slide(h, kw["title"], kw["image_path"], kw.get("caption", "")),
    ),
    _make(
        "add_textbox",
        "Add a free text box to the last slide.",
        {
            "x": {"type": "number"}, "y": {"type": "number"},
            "w": {"type": "number"}, "height": {"type": "number"},
            "text": {"type": "string"}, "size": {"type": "integer"},
            "bold": {"type": "boolean"},
        },
        ["x", "y", "w", "height", "text", "size"],
        lambda h, **kw: _add_box(h, _box_from_kw(kw)),
    ),
    _make(
        "save_deck",
        "Save current deck to a .pptx file (default workspace/deck.pptx).",
        {"path": {"type": "string"}},
        [],
        lambda h, **kw: _save(h, kw.get("path")),
    ),
    _make(
        "deck_info",
        "List slides and their contents in the current deck.",
        {},
        [],
        lambda h, **kw: _deck_info(h),
    ),
    _make(
        "shape_inventory",
        "Inspect editable shapes with stable slide number, shape id, geometry, and text. Call before modifying an existing deck.",
        {"slide_number": {"type": "integer"}},
        [],
        lambda h, **kw: _shape_inventory(h, kw.get("slide_number")),
    ),
    _make(
        "replace_shape_text",
        "Replace text in one shape identified by shape_inventory while preserving its primary font styling.",
        {"slide_number": {"type": "integer"}, "shape_id": {"type": "integer"}, "text": {"type": "string"}},
        ["slide_number", "shape_id", "text"],
        lambda h, **kw: _replace_text(h, kw["slide_number"], kw["shape_id"], kw["text"]),
    ),
    _make(
        "set_shape_geometry",
        "Move and resize an existing shape using slide-inch coordinates. Inspect with shape_inventory first.",
        {"slide_number": {"type": "integer"}, "shape_id": {"type": "integer"}, "x": {"type": "number"}, "y": {"type": "number"}, "w": {"type": "number"}, "height": {"type": "number"}},
        ["slide_number", "shape_id", "x", "y", "w", "height"],
        lambda h, **kw: _set_shape_geometry(h, kw["slide_number"], kw["shape_id"], kw["x"], kw["y"], kw["w"], kw["height"]),
    ),
    _make(
        "delete_shape",
        "Delete one shape identified by shape_inventory.",
        {"slide_number": {"type": "integer"}, "shape_id": {"type": "integer"}},
        ["slide_number", "shape_id"],
        lambda h, **kw: _delete_shape(h, kw["slide_number"], kw["shape_id"]),
    ),
    _make(
        "delete_slide",
        "Delete a slide by its current one-based position.",
        {"slide_number": {"type": "integer"}},
        ["slide_number"],
        lambda h, **kw: _delete_slide(h, kw["slide_number"]),
    ),
    _make(
        "move_slide",
        "Move a slide from its current one-based position to another position.",
        {"slide_number": {"type": "integer"}, "new_position": {"type": "integer"}},
        ["slide_number", "new_position"],
        lambda h, **kw: _move_slide(h, kw["slide_number"], kw["new_position"]),
    ),
    _make(
        "ppt_verify",
        "Run structural verification on the deck: empty text boxes, overflow proxy. Returns a report.",
        {},
        [],
        lambda h, **kw: _verify(h),
    ),
    _make(
        "render_deck",
        "Render a saved .pptx to PNG slides for visual inspection. On Windows uses installed PowerPoint; Linux benchmark images should provide LibreOffice.",
        {"path": {"type": "string"}, "output_dir": {"type": "string"}},
        ["path"],
        lambda h, **kw: _render(h, kw["path"], kw.get("output_dir", "rendered")),
    ),
    _make(
        "inspect_rendered_deck",
        "Inspect rendered PNG slides for blank output and edge-clipping risk. This is a deterministic gate, not a substitute for semantic visual review.",
        {"output_dir": {"type": "string"}},
        [],
        lambda h, **kw: _inspect_rendered(h, kw.get("output_dir", "rendered")),
    ),
]
