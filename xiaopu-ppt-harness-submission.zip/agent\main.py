"""ppt_agent — coding + PowerPoint agent harness
Usage:
  agent                     interactive terminal UI (like codex)
  agent "task..."           single-shot task (auto offline demo if no API key)
  agent --model M           override model id
"""

import json
import sys

from . import config
from .demo import run_demo
from .redact import redact


def _force_utf8_stdio() -> None:
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


def _print_tool(name: str, args: str, out: str) -> None:
    try:
        args_pretty = json.dumps(json.loads(args), ensure_ascii=False)[:160]
    except Exception:
        args_pretty = args[:160]
    args_pretty = redact(args_pretty)
    print(f"  > {name}({args_pretty})")
    for line in (out or "").splitlines()[:12]:
        print(f"    {redact(line)}")


def _print_help() -> None:
    print(__doc__)


def main() -> int:
    _force_utf8_stdio()
    config.load_dotenv()
    args = [a for a in sys.argv[1:] if not a.startswith("--fly--")]

    if any(a in ("-h", "--help") for a in args):
        _print_help()
        return 0

    model = None
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--model":
            model = args[i + 1]
            i += 2
        elif a.startswith("--model="):
            model = a.split("=", 1)[1]
            i += 1
        else:
            positional.append(a)
            i += 1

    task = " ".join(positional).strip()

    if task:
        # single-shot mode
        try:
            from .harness import Harness
        except Exception as e:
            print(f"[import error] {e}")
            return 1

        h = Harness(model=model)
        h.attach_printer(_print_tool)
        if config.api_key() or config.anthropic_api_key():
            try:
                print(h.run(task))
            except Exception as e:
                print(f"[error] {type(e).__name__}: {e}")
                return 1
            return 0
        print("[offline] no API key -> demo driver")
        print(run_demo(h, task))
        return 0

    # interactive terminal UI
    from .tui import run_tui

    return run_tui(model=model)


if __name__ == "__main__":
    _force_utf8_stdio()
    sys.exit(main())
