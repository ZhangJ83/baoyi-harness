"""Offline demo driver for testing without an API key."""

def run_demo(harness, task: str) -> str:
    from .tools.registry import dispatch

    harness.reset()
    dispatch("new_deck", '{"title": "咖啡鉴赏与文化概览", "subtitle": "从豆到杯的奇妙之旅"}', harness)
    dispatch("add_metric_slide", '{"title": "一杯咖啡背后的全球产业", "metrics": [{"value": "70+", "label": "生产国", "detail": "横跨咖啡带"}, {"value": "2 种", "label": "主流商业品种", "detail": "Arabica / Robusta"}, {"value": "4 阶段", "label": "风味形成链路", "detail": "产地·处理·烘焙·萃取"}], "takeaway": "咖啡风味不是单一变量，而是一条可被理解和控制的系统链路。"}', harness)
    dispatch("add_two_column_slide", '{"title": "两大主流品种：不是高低，而是取舍", "left_title": "Arabica · 阿拉比卡", "left_bullets": ["花果香与酸质更突出", "适合手冲与精品表达", "种植条件要求更高"], "right_title": "Robusta · 罗布斯塔", "right_bullets": ["醇厚、苦感与咖啡因更强", "常用于意式拼配与速溶", "抗病性与产量更高"]}', harness)
    dispatch("add_table_slide", '{"title": "把风味偏好翻译成冲煮选择", "columns": ["偏好", "豆种/烘焙", "建议方法", "关键变量"], "rows": [["明亮果香", "浅烘 Arabica", "手冲", "水温 90–94°C"], ["均衡甜感", "中烘拼配", "滤泡/美式", "中等研磨"], ["浓郁醇厚", "深烘或 Robusta 拼配", "意式", "粉水比与压力"]]}', harness)
    dispatch("add_process_slide", '{"title": "从今天开始的三步品鉴法", "steps": [{"title": "先闻", "detail": "记录最先出现的香气联想，不急着寻找标准答案。"}, {"title": "再喝", "detail": "分别感受酸、甜、苦与醇厚度，建立自己的词汇。"}, {"title": "最后比较", "detail": "一次只改变一个冲煮变量，让差异变得可解释。"}], "takeaway": "品鉴不是背风味表，而是建立一套可重复的观察方法。"}', harness)
    dispatch("ppt_verify", "{}", harness)
    return dispatch("save_deck", '{"path": "coffee_demo.pptx"}', harness)
