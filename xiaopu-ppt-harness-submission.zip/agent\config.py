import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent  # project root: .env, workspace/, memory/ live here
ENV_FILE = ROOT / ".env"
WORKSPACE = ROOT / "workspace"


def load_dotenv() -> None:
    if not ENV_FILE.exists():
        return
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip().strip("\"'"))


def provider() -> str:
    return os.getenv("PROVIDER", "openai").strip().lower()


def api_base() -> str:
    return os.getenv("OPENAI_BASE_URL", "https://api.deepseek.com").strip()


def model() -> str:
    return os.getenv("OPENAI_MODEL", "deepseek-v4-flash").strip()


def api_key() -> str:
    return os.getenv("OPENAI_API_KEY", "").strip()


def anthropic_api_key() -> str:
    return os.getenv("ANTHROPIC_API_KEY", "").strip()


def anthropic_api_base() -> str:
    return os.getenv("ANTHROPIC_BASE_URL", "https://api.deepseek.com/anthropic").strip()


def anthropic_model() -> str:
    return os.getenv("ANTHROPIC_MODEL", "deepseek-v4-flash").strip()


def anthropic_max_tokens() -> int:
    try:
        return max(256, int(os.getenv("ANTHROPIC_MAX_TOKENS", "4096")))
    except ValueError:
        return 4096


def max_steps() -> int:
    try:
        return max(1, int(os.getenv("MAX_STEPS", "25")))
    except ValueError:
        return 25


def int_setting(name: str, default: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except ValueError:
        return default


def float_setting(name: str, default: float, minimum: float = 0.0) -> float:
    try:
        return max(minimum, float(os.getenv(name, str(default))))
    except ValueError:
        return default


def max_tool_calls() -> int:
    return int_setting("MAX_TOOL_CALLS", 120)


def max_total_tokens() -> int:
    return int_setting("MAX_TOTAL_TOKENS", 120_000)


def max_output_tokens() -> int:
    return int_setting("OPENAI_MAX_TOKENS", 4096)


def max_generated_output_tokens() -> int:
    return int_setting("MAX_GENERATED_OUTPUT_TOKENS", max_total_tokens())


def api_retries() -> int:
    return int_setting("API_RETRIES", 3, minimum=0)


def api_timeout() -> float:
    return float_setting("API_TIMEOUT", 120.0, minimum=1.0)


def max_command_timeout() -> int:
    return int_setting("MAX_COMMAND_TIMEOUT", 600)


def max_cost_usd() -> float:
    return float_setting("MAX_COST_USD", 0.10)


def command_policy() -> str:
    value = os.getenv("COMMAND_POLICY", "ask").strip().lower()
    return value if value in {"allow", "ask", "deny"} else "ask"


def isolated_benchmark() -> bool:
    return os.getenv("ISOLATED_BENCHMARK", "0").strip().lower() in {"1", "true", "yes"}


def sandbox_root() -> Path:
    p = Path(os.getenv("WORKSPACE", str(WORKSPACE)))
    p.mkdir(parents=True, exist_ok=True)
    return p
