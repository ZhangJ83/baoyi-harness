"""Code-focused tools (aliases over the fs sandbox) — kept for interview clarity."""
from typing import Any

from .. import memory
from ..state import Status, TaskItem


def _make(name, description, params, required, fn):
    return (
        {
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": {"type": "object", "properties": params, "required": required},
            },
        },
        fn,
    )


def _note(h, text: str):
    memory.append_note(text)
    return "note appended to session memory."


def _finish(h, summary: str):
    if not summary.strip():
        raise ValueError("finish summary cannot be empty")
    if h.state.changed_files and not h.state.fresh_evidence():
        raise ValueError(f"cannot finish: no passing verification evidence for current mutation epoch {h.state.mutation_epoch}")
    h._done = summary.strip()
    h.state.final_summary = h._done
    return "task marked complete"


def _tasks(h, items: list[dict]):
    parsed = []
    for item in items:
        try:
            status = Status(item.get("status", "pending"))
        except ValueError as exc:
            raise ValueError(f"invalid task status: {item.get('status')}") from exc
        parsed.append(TaskItem(id=str(item["id"]), content=str(item["content"]), status=status, evidence=list(item.get("evidence") or [])))
    active = sum(item.status is Status.IN_PROGRESS for item in parsed)
    if active > 1:
        raise ValueError("at most one task may be in_progress")
    h.state.tasks = parsed
    return h.state.compact()


code_tools = [
    _make(
        "update_tasks",
        "Replace the structured task list. Use for work with 3+ meaningful steps; keep at most one item in_progress.",
        {"items": {"type": "array", "items": {"type": "object", "properties": {"id": {"type": "string"}, "content": {"type": "string"}, "status": {"type": "string", "enum": ["pending", "in_progress", "completed", "blocked"]}, "evidence": {"type": "array", "items": {"type": "string"}}}, "required": ["id", "content", "status"]}}},
        ["items"],
        lambda h, **kw: _tasks(h, kw["items"]),
    ),
    _make(
        "remember",
        "Append a short note to persistent session memory (styles, user preferences, decisions).",
        {"text": {"type": "string"}},
        ["text"],
        lambda h, **kw: _note(h, kw["text"]),
    ),
    _make(
        "finish",
        "Declare the task complete. Provide the final summary for the user.",
        {"summary": {"type": "string"}},
        ["summary"],
        lambda h, **kw: _finish(h, kw["summary"]),
    ),
]
