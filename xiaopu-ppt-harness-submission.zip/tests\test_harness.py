import json
import os
import tempfile
import unittest
from unittest.mock import patch

from agent.harness import Harness
from agent.llm import AssistantMessage, LLMReply, ToolCall, ToolFn
from agent.state import RunState
from agent.hooks import ToolEvent


class SequenceLLM:
    model = "fake"

    def __init__(self, replies):
        self.replies = iter(replies)

    def chat(self, messages, tools=None):
        return next(self.replies)


class BudgetCaptureLLM:
    model = "fake"

    def __init__(self, reply):
        self.reply = reply
        self.seen = []

    def chat(self, messages, tools=None):
        self.seen.append(os.environ.get("OPENAI_MAX_TOKENS"))
        return self.reply


class HarnessTests(unittest.TestCase):
    def make_harness(self, replies):
        harness = Harness.__new__(Harness)
        harness.llm = SequenceLLM(replies)
        harness.max_steps = 5
        harness.messages = []
        harness.deck = None
        harness.on_tool = lambda *args: None
        harness.started = True
        harness.state = RunState()
        harness._done = None
        harness.pre_tool_hooks = []
        harness.post_tool_hooks = []
        harness.loaded_skills = set()
        return harness

    def test_finish_stops_loop_and_tracks_usage(self):
        call = ToolCall("1", ToolFn("finish", json.dumps({"summary": "done"})))
        reply = LLMReply.from_message(AssistantMessage(tool_calls=[call]), total_tokens=17)
        harness = self.make_harness([reply])
        self.assertEqual(harness.run("answer only"), "done")
        self.assertEqual(harness.state.total_tokens, 17)

    def test_changed_files_require_evidence(self):
        finish = ToolCall("1", ToolFn("finish", json.dumps({"summary": "done"})))
        verify = ToolCall("2", ToolFn("run_python", json.dumps({"code": "assert 1 + 1 == 2\nprint('ok')"})))
        final = LLMReply.from_message(AssistantMessage(content="verified now"))
        harness = self.make_harness([LLMReply.from_message(AssistantMessage(tool_calls=[finish])), LLMReply.from_message(AssistantMessage(tool_calls=[verify])), final])
        harness.state.record_change("x.py")
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"WORKSPACE": tmp}):
            self.assertEqual(harness.run("fix"), "verified now")
            self.assertEqual(harness.state.final_summary, "verified now")

    def test_compaction_keeps_latest_tool_pair_with_user_anchor(self):
        harness = self.make_harness([])
        harness.messages = [
            {"role": "system", "content": "rules"},
            {"role": "user", "content": "x" * 50000},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "7", "type": "function", "function": {"name": "read_file", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "7", "content": "latest"},
        ]
        harness._maybe_compact()
        self.assertEqual([message["role"] for message in harness.messages], ["system", "system", "user", "assistant", "tool"])
        self.assertEqual(harness.messages[-1]["tool_call_id"], "7")

    def test_end_to_end_repository_repair(self):
        def tool(call_id, name, arguments):
            return LLMReply.from_message(AssistantMessage(tool_calls=[ToolCall(call_id, ToolFn(name, json.dumps(arguments)))]), total_tokens=10)

        replies = [
            tool("1", "update_tasks", {"items": [{"id": "1", "content": "fix add", "status": "in_progress"}]}),
            tool("2", "read_file", {"path": "calculator.py"}),
            tool("3", "edit_file", {"path": "calculator.py", "old": "return a - b", "new": "return a + b"}),
            tool("4", "run_python", {"code": "from calculator import add\nassert add(2, 3) == 5\nprint('verification passed')"}),
            tool("5", "update_tasks", {"items": [{"id": "1", "content": "fix add", "status": "completed", "evidence": ["assert add(2,3)==5"]}]}),
            tool("6", "finish", {"summary": "Fixed calculator.add and verified add(2, 3) == 5."}),
        ]
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"WORKSPACE": tmp}):
            path = os.path.join(tmp, "calculator.py")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("def add(a, b):\n    return a - b\n")
            harness = self.make_harness(replies)
            harness.started = False
            harness.max_steps = 10
            answer = harness.run("Fix calculator.add and verify it")
            self.assertIn("verified", answer.lower())
            with open(path, encoding="utf-8") as handle:
                self.assertIn("return a + b", handle.read())
            self.assertEqual(harness.state.tool_calls, 6)
            self.assertEqual(harness.state.total_tokens, 60)

    def test_hooks_can_rewrite_input_and_output(self):
        call = ToolCall("1", ToolFn("finish", json.dumps({"summary": "before"})))
        harness = self.make_harness([LLMReply.from_message(AssistantMessage(tool_calls=[call]))])
        harness.add_pre_tool_hook(lambda event: json.dumps({"summary": "after"}) if event.name == "finish" else event.arguments)
        seen = []
        harness.add_post_tool_hook(lambda event: (seen.append(event), event.output)[1])
        self.assertEqual(harness.run("answer"), "after")
        self.assertEqual(seen[0].name, "finish")

    def test_later_turn_can_load_powerpoint_skill(self):
        first = LLMReply.from_message(AssistantMessage(content="code answer"))
        second = LLMReply.from_message(AssistantMessage(content="ppt answer"))
        harness = self.make_harness([first, second])
        self.assertEqual(harness.run("explain this Python function"), "code answer")
        self.assertNotIn("powerpoint", harness.loaded_skills)
        self.assertEqual(harness.run("render this PPT slide deck"), "ppt answer")
        self.assertIn("powerpoint", harness.loaded_skills)
        self.assertTrue(any(message["role"] == "system" and "Dynamically loaded" in message["content"] for message in harness.messages))

    def test_repeated_identical_action_has_circuit_breaker(self):
        def repeat(call_id):
            return LLMReply.from_message(
                AssistantMessage(tool_calls=[ToolCall(call_id, ToolFn("search_text", json.dumps({"query": "missing"})))]),
                total_tokens=5,
            )
        harness = self.make_harness([repeat("1"), repeat("2"), repeat("3"), repeat("4")])
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"WORKSPACE": tmp}):
            result = harness.run("find the missing symbol")
        self.assertIn("repeated identical action", result)
        self.assertEqual(harness.state.total_tokens, 15)

    def test_output_cap_uses_remaining_budget_and_restores_environment(self):
        harness = self.make_harness([LLMReply.from_message(AssistantMessage(content="done"), total_tokens=100)])
        capture = BudgetCaptureLLM(LLMReply.from_message(AssistantMessage(content="done"), total_tokens=100))
        harness.llm = capture
        with patch.dict(os.environ, {"MAX_TOTAL_TOKENS": "500", "OPENAI_MAX_TOKENS": "700"}, clear=False):
            self.assertEqual(harness.run("answer"), "done")
            self.assertEqual(os.environ["OPENAI_MAX_TOKENS"], "700")
        self.assertEqual(capture.seen, ["500"])

    def test_generated_output_cap_is_separate_and_blocks_overrun_tools(self):
        finish = ToolCall("1", ToolFn("finish", json.dumps({"summary": "must not execute"})))
        reply = LLMReply.from_message(
            AssistantMessage(tool_calls=[finish]), total_tokens=700,
            input_tokens=100, output_tokens=600,
        )
        harness = self.make_harness([reply])
        with patch.dict(os.environ, {"MAX_TOTAL_TOKENS": "2000", "MAX_GENERATED_OUTPUT_TOKENS": "500"}, clear=False):
            result = harness.run("answer")
        self.assertIn("exceeded", result)
        self.assertIsNone(harness._done)
        self.assertEqual(harness.state.input_tokens, 100)
        self.assertEqual(harness.state.generated_output_tokens, 600)

    def test_per_turn_cap_uses_remaining_generated_output_budget(self):
        capture = BudgetCaptureLLM(LLMReply.from_message(
            AssistantMessage(content="done"), total_tokens=100, input_tokens=50, output_tokens=50,
        ))
        harness = self.make_harness([])
        harness.llm = capture
        harness.state.generated_output_tokens = 200
        with patch.dict(os.environ, {"MAX_TOTAL_TOKENS": "2000", "MAX_GENERATED_OUTPUT_TOKENS": "500", "OPENAI_MAX_TOKENS": "1000"}, clear=False):
            self.assertEqual(harness.run("answer"), "done")
        self.assertEqual(capture.seen, ["300"])

    def test_missing_provider_usage_fails_authoritative_ledger(self):
        harness = self.make_harness([LLMReply.from_message(AssistantMessage(content="done"))])
        self.assertEqual(harness.run("answer"), "done")
        self.assertFalse(harness.state.provider_usage_authoritative)


if __name__ == "__main__":
    unittest.main()
