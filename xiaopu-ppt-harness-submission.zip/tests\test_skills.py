import unittest

from agent.skills import Skill, match


class SkillTests(unittest.TestCase):
    def test_progressive_matching_avoids_generic_create(self):
        skill = Skill("powerpoint", "Create, modify, render PPT and PowerPoint slide decks", "body", None)
        self.assertEqual(match("create a Python parser", [skill]), [])
        self.assertEqual(match("render this PPT slide deck", [skill]), [skill])


if __name__ == "__main__":
    unittest.main()
