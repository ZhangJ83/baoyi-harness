from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Status(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    BLOCKED = "blocked"


@dataclass
class TaskItem:
    id: str
    content: str
    status: Status = Status.PENDING
    evidence: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class EvidenceRecord:
    kind: str
    summary: str
    epoch: int
    passed: bool = True
    scope: str = "workspace"


@dataclass
class RunState:
    goal: str = ""
    tasks: list[TaskItem] = field(default_factory=list)
    tool_calls: int = 0
    total_tokens: int = 0
    input_tokens: int = 0
    generated_output_tokens: int = 0
    provider_usage_authoritative: bool = True
    failures: dict[str, int] = field(default_factory=dict)
    changed_files: set[str] = field(default_factory=set)
    mutation_epoch: int = 0
    evidence: list[EvidenceRecord] = field(default_factory=list)
    final_summary: str | None = None
    budget_overrun: bool = False

    def record_change(self, path: str) -> None:
        self.mutation_epoch += 1
        self.changed_files.add(path)

    def record_changes(self, paths: list[str]) -> None:
        if not paths:
            return
        self.mutation_epoch += 1
        self.changed_files.update(paths)

    def record_evidence(self, kind: str, summary: str, passed: bool = True, scope: str = "workspace") -> None:
        self.evidence.append(EvidenceRecord(kind=kind, summary=summary, epoch=self.mutation_epoch, passed=passed, scope=scope))

    def fresh_evidence(self, scope: str = "workspace") -> list[EvidenceRecord]:
        return [record for record in self.evidence if record.passed and record.epoch == self.mutation_epoch and record.scope == scope]

    def compact(self) -> str:
        lines = [f"Goal: {self.goal}", f"Tool calls: {self.tool_calls}", f"Tokens: {self.total_tokens}", f"Input tokens: {self.input_tokens}", f"Generated output tokens: {self.generated_output_tokens}", f"Provider usage authoritative: {self.provider_usage_authoritative}", f"Mutation epoch: {self.mutation_epoch}"]
        lines.extend(f"- [{item.status.value}] {item.id}: {item.content}" for item in self.tasks)
        if self.changed_files:
            lines.append("Changed files: " + ", ".join(sorted(self.changed_files)))
        if self.evidence:
            lines.append("Recent evidence:\n" + "\n".join(f"- epoch={record.epoch} {record.kind}: {record.summary}" for record in self.evidence[-8:]))
        return "\n".join(lines)
