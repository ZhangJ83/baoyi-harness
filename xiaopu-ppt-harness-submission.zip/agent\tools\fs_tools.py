"""Filesystem tools, sandboxed to WORKSPACE."""
import os
import re
from pathlib import Path
from typing import Any

from .. import config
from ..permissions import Decision, evaluate_shell, path_within

Schema = dict[str, Any]


def _root():
    return config.sandbox_root()


def _safe_environment() -> dict[str, str]:
    env = os.environ.copy()
    for name in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY"):
        env.pop(name, None)
    return env


def _resolve(rel: str) -> Path:
    root = _root()
    p = (root / rel).resolve()
    if not path_within(root, p):
        raise PermissionError(f"path escapes workspace sandbox: {rel}")
    return p


def _make(name: str, description: str, params: dict[str, dict], required: list[str], fn):
    return (
        {
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": {"type": "object", "properties": params, "required": required},
            },
        },
        fn,
    )


def _read(h, path: str, max_chars: int = 12000, start_line: int = 1, end_line: int | None = None):
    p = _resolve(path)
    if not p.exists():
        return f"not found: {path}"
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    if not lines:
        return "(empty file)"
    if start_line < 1:
        raise ValueError("start_line must be >= 1")
    if start_line > len(lines):
        raise ValueError(f"start_line {start_line} exceeds file length {len(lines)}")
    stop = min(len(lines), end_line) if end_line is not None else len(lines)
    if stop < start_line:
        raise ValueError("end_line must be >= start_line")
    text = "\n".join(f"{number:6d} | {lines[number - 1]}" for number in range(start_line, stop + 1))
    if len(text) > max_chars:
        head = text[: max_chars * 3 // 4]
        tail = text[-max_chars // 4 :]
        return head + f"\n[truncated {len(text) - len(head) - len(tail)} chars]\n" + tail
    return text


def _list_dir(h, path: str = ""):
    p = _resolve(path)
    if not p.exists() or not p.is_dir():
        return f"not a dir: {path}"
    return "\n".join(sorted(x.name for x in p.iterdir()))


def _glob(h, pattern: str = "**/*", limit: int = 500):
    root = _root()
    matches = [str(p.relative_to(root)) for p in root.glob(pattern) if p.is_file()]
    return "\n".join(matches[:limit]) + (f"\n[truncated: {len(matches)} matches]" if len(matches) > limit else "")


def _search(h, query: str, pattern: str = "**/*", limit: int = 200):
    root = _root()
    hits = []
    for p in root.glob(pattern):
        if not p.is_file() or p.stat().st_size > 2_000_000:
            continue
        try:
            for number, line in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if query.lower() in line.lower():
                    hits.append(f"{p.relative_to(root)}:{number}:{line[:300]}")
                    if len(hits) >= limit:
                        return "\n".join(hits) + "\n[truncated]"
        except OSError:
            continue
    return "\n".join(hits) or "no matches"


def _edit(h, path: str, old: str, new: str, replace_all: bool = False):
    p = _resolve(path)
    text = p.read_text(encoding="utf-8")
    count = text.count(old)
    if count == 0:
        raise ValueError("old text not found")
    if count > 1 and not replace_all:
        raise ValueError(f"old text is not unique ({count} matches); provide more context or set replace_all")
    updated = text.replace(old, new) if replace_all else text.replace(old, new, 1)
    p.write_text(updated, encoding="utf-8")
    h.state.record_change(str(p.relative_to(_root())))
    return f"edited {path}: {count if replace_all else 1} replacement(s)"


def _apply_edits(h, edits: list[dict]):
    if not edits or len(edits) > 50:
        raise ValueError("apply_edits requires 1-50 edits")
    staged: dict[Path, str] = {}
    totals: dict[Path, int] = {}
    for index, edit in enumerate(edits):
        p = _resolve(edit["path"])
        if not p.is_file():
            raise FileNotFoundError(edit["path"])
        current = staged.get(p, p.read_text(encoding="utf-8"))
        old, new = edit["old"], edit["new"]
        if not old:
            raise ValueError(f"edit {index}: old text cannot be empty")
        count = current.count(old)
        expected = int(edit.get("expected_replacements", 1))
        if expected < 1:
            raise ValueError(f"edit {index}: expected_replacements must be >= 1")
        if count != expected:
            raise ValueError(f"edit {index} ({edit['path']}): expected {expected} matches, found {count}; no files changed")
        staged[p] = current.replace(old, new, expected)
        totals[p] = totals.get(p, 0) + expected
    for p, content in staged.items():
        p.write_text(content, encoding="utf-8")
    h.state.record_changes([str(path.relative_to(_root())) for path in staged])
    return "atomic edits applied:\n" + "\n".join(f"{p.relative_to(_root())}: {totals[p]} replacement(s)" for p in staged)


def _write(h, path: str, content: str):
    p = _resolve(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    h.state.record_change(str(p.relative_to(_root())))
    return f"wrote {len(content)} chars -> {path}"


def _run(h, command: str, timeout: int = 60):
    """Run a shell command from the workspace. Prefer `python` scripts via run_code."""
    import subprocess
    root = _root()
    permission = evaluate_shell(command, config.command_policy(), config.isolated_benchmark())
    if permission.decision is not Decision.ALLOW:
        return f"PERMISSION {permission.decision.value.upper()}: {permission.reason}"
    timeout = max(1, min(timeout, config.max_command_timeout()))
    try:
        proc = subprocess.run(
            command,
            shell=True,
            cwd=str(root),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=_safe_environment(),
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode("utf-8", "replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return f"exit_code=124\nTIMEOUT after {timeout}s\n{stdout}\n[stderr]\n{stderr}"[:16000]
    out = (proc.stdout or "") + "\n[stderr]\n" + (proc.stderr or "")
    result = f"exit_code={proc.returncode}\n{out.strip()}"[:16000]
    verifier = re.search(r"\b(pytest|unittest|tox|nox|cargo\s+test|go\s+test|npm\s+test|pnpm\s+test|bun\s+test|gradle\w*\s+test|mvn\w*\s+test|make\s+(?:test|check)|ruff|mypy|pyright|eslint|tsc|cargo\s+check|compileall)\b", command, re.IGNORECASE)
    if proc.returncode == 0 and verifier:
        h.state.record_evidence("shell_verifier", f"shell passed: {command[:200]}")
    return result


def _run_py(h, code: str, timeout: int = 60, save_as: str = ""):
    """Run a Python snippet in the sandbox; may use python-pptx (import pptx)."""
    import subprocess
    import sys
    root = _root()
    if save_as:
        dst = _resolve(save_as)
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(code, encoding="utf-8")
    else:
        dst = root / "_inline.py"
        dst.write_text(code, encoding="utf-8")
    timeout = max(1, min(timeout, config.max_command_timeout()))
    try:
        proc = subprocess.run(
            [sys.executable, str(dst)],
            cwd=str(root),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=_safe_environment(),
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode("utf-8", "replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return f"exit_code=124\nTIMEOUT after {timeout}s\n{stdout}\n[stderr]\n{stderr}"[:16000]
    result = f"exit_code={proc.returncode}\n{(proc.stdout or '')}\n[stderr]\n{(proc.stderr or '')}"[:16000]
    if proc.returncode == 0 and re.search(r"\b(assert|unittest|pytest|compile)\b", code):
        h.state.record_evidence("python_verifier", f"python passed: {dst.name}")
    return result


def _git(h, arguments: list[str], max_chars: int = 16000) -> str:
    import subprocess
    proc = subprocess.run(
        ["git", *arguments],
        cwd=str(_root()),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=_safe_environment(),
        timeout=30,
    )
    output = ((proc.stdout or "") + ("\n[stderr]\n" + proc.stderr if proc.stderr else "")).strip()
    if len(output) > max_chars:
        output = output[: max_chars * 3 // 4] + "\n[truncated]\n" + output[-max_chars // 4 :]
    return f"exit_code={proc.returncode}\n{output or '(no output)'}"


fs_tools = [
    _make(
        "read_file",
        "Read a line-numbered UTF-8 text range. Use start_line/end_line to avoid flooding context.",
        {"path": {"type": "string"}, "max_chars": {"type": "integer"}, "start_line": {"type": "integer"}, "end_line": {"type": "integer"}},
        ["path"],
        lambda h, **kw: _read(h, kw["path"], kw.get("max_chars", 12000), kw.get("start_line", 1), kw.get("end_line")),
    ),
    _make(
        "write_file",
        "Write text content to a file in the workspace (overwrites).",
        {"path": {"type": "string"}, "content": {"type": "string"}},
        ["path", "content"],
        lambda h, **kw: _write(h, kw["path"], kw["content"]),
    ),
    _make(
        "list_dir",
        "List files/dirs inside a workspace subdirectory.",
        {"path": {"type": "string"}},
        [],
        lambda h, **kw: _list_dir(h, kw.get("path", "")),
    ),
    _make(
        "glob_files",
        "List workspace files matching a glob such as **/*.py. Use before broad reads.",
        {"pattern": {"type": "string"}, "limit": {"type": "integer"}},
        [],
        lambda h, **kw: _glob(h, kw.get("pattern", "**/*"), kw.get("limit", 500)),
    ),
    _make(
        "search_text",
        "Search text case-insensitively across workspace files and return path:line matches.",
        {"query": {"type": "string"}, "pattern": {"type": "string"}, "limit": {"type": "integer"}},
        ["query"],
        lambda h, **kw: _search(h, kw["query"], kw.get("pattern", "**/*"), kw.get("limit", 200)),
    ),
    _make(
        "edit_file",
        "Replace an exact text span in a UTF-8 file. The old text must be unique unless replace_all is true.",
        {"path": {"type": "string"}, "old": {"type": "string"}, "new": {"type": "string"}, "replace_all": {"type": "boolean"}},
        ["path", "old", "new"],
        lambda h, **kw: _edit(h, kw["path"], kw["old"], kw["new"], kw.get("replace_all", False)),
    ),
    _make(
        "apply_edits",
        "Atomically apply 1-50 exact replacements across files. Every match count is checked before any file is written.",
        {"edits": {"type": "array", "minItems": 1, "maxItems": 50, "items": {"type": "object", "properties": {"path": {"type": "string"}, "old": {"type": "string"}, "new": {"type": "string"}, "expected_replacements": {"type": "integer"}}, "required": ["path", "old", "new"]}}},
        ["edits"],
        lambda h, **kw: _apply_edits(h, kw["edits"]),
    ),
    _make(
        "run_python",
        "Execute Python code in the sandbox (python-pptx available).",
        {"code": {"type": "string"}, "timeout": {"type": "integer"}},
        ["code"],
        lambda h, **kw: _run_py(h, kw["code"], kw.get("timeout", 60)),
    ),
    _make(
        "run_shell",
        "Run a shell command in the sandbox (use sparingly).",
        {"command": {"type": "string"}, "timeout": {"type": "integer"}},
        ["command"],
        lambda h, **kw: _run(h, kw["command"], kw.get("timeout", 60)),
    ),
    _make(
        "git_status",
        "Read repository status without invoking a shell. Use before and after edits.",
        {},
        [],
        lambda h, **kw: _git(h, ["status", "--short", "--branch"]),
    ),
    _make(
        "git_diff",
        "Read the current Git diff. Optionally restrict to one workspace-relative path.",
        {"path": {"type": "string"}, "staged": {"type": "boolean"}, "max_chars": {"type": "integer"}},
        [],
        lambda h, **kw: _git(h, ["diff", *(["--cached"] if kw.get("staged") else []), "--", *([kw["path"]] if kw.get("path") else [])], kw.get("max_chars", 16000)),
    ),
]
