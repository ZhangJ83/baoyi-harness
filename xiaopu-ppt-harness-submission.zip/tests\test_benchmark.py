import unittest

from agent.benchmark import is_provider_unavailable


class BenchmarkDiagnosticsTests(unittest.TestCase):
    def test_connection_failures_are_infrastructure_diagnostics(self):
        self.assertTrue(is_provider_unavailable("APIConnectionError: Connection error."))
        self.assertTrue(is_provider_unavailable("request timed out"))

    def test_regular_agent_errors_are_not_reclassified(self):
        self.assertFalse(is_provider_unavailable("SchemaValidationError: invalid tool"))


if __name__ == "__main__":
    unittest.main()
