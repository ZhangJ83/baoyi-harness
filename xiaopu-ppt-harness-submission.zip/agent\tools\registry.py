import json
from typing import Any, Callable

from .ppt_tools import ppt_tools
from .fs_tools import fs_tools
from .code_tools import code_tools

ToolDef = dict[str, Any]

_ALL: list[tuple[ToolDef, Callable]] = [*ppt_tools, *fs_tools, *code_tools]
TOOLS: list[ToolDef] = [t[0] for t in _ALL]
_PPT_NAMES = {item[0]["function"]["name"] for item in ppt_tools}
_PPT_MUTATORS = {
    "new_deck", "add_slide", "add_two_column_slide", "add_metric_slide",
    "add_table_slide", "add_process_slide", "add_image_slide", "add_textbox",
    "replace_shape_text", "set_shape_geometry", "delete_shape", "delete_slide",
    "move_slide", "set_speaker_notes", "save_deck",
}
_INDEX: dict[str, Callable] = {t[0]["function"]["name"]: t[1] for t in _ALL}
_SCHEMAS: dict[str, dict] = {t[0]["function"]["name"]: t[0]["function"]["parameters"] for t in _ALL}


def select_tools(task: str, has_deck: bool = False) -> list[ToolDef]:
    text = task.lower()
    ppt_markers = ("ppt", "pptx", "powerpoint", "slide", "deck", "演示", "幻灯片", "排版")
    include_ppt = has_deck or any(marker in text for marker in ppt_markers)
    if include_ppt:
        return TOOLS
    return [tool for tool in TOOLS if tool["function"]["name"] not in _PPT_NAMES]


def _validate(value: Any, schema: dict, path: str = "arguments") -> None:
    expected = schema.get("type")
    valid = {
        "object": lambda item: isinstance(item, dict),
        "array": lambda item: isinstance(item, list),
        "string": lambda item: isinstance(item, str),
        "integer": lambda item: isinstance(item, int) and not isinstance(item, bool),
        "number": lambda item: isinstance(item, (int, float)) and not isinstance(item, bool),
        "boolean": lambda item: isinstance(item, bool),
    }
    if expected in valid and not valid[expected](value):
        raise TypeError(f"{path} must be {expected}")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(f"{path} must be one of {schema['enum']}")
    if expected == "object":
        for name in schema.get("required", []):
            if name not in value:
                raise ValueError(f"missing required argument: {path}.{name}")
        properties = schema.get("properties", {})
        for name, item in value.items():
            if name in properties:
                _validate(item, properties[name], f"{path}.{name}")
    if expected == "array":
        if "minItems" in schema and len(value) < schema["minItems"]:
            raise ValueError(f"{path} requires at least {schema['minItems']} items")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            raise ValueError(f"{path} allows at most {schema['maxItems']} items")
        item_schema = schema.get("items")
        if item_schema:
            for index, item in enumerate(value):
                _validate(item, item_schema, f"{path}[{index}]")


def dispatch(name: str, arguments_json: str, harness) -> str:
    fn = _INDEX.get(name)
    if fn is None:
        raise KeyError(f"unknown tool: {name}")
    try:
        args = json.loads(arguments_json or "{}")
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON arguments at character {exc.pos}") from exc
    if not isinstance(args, dict):
        raise TypeError("tool arguments must be a JSON object")
    _validate(args, _SCHEMAS[name])
    epoch_before = getattr(getattr(harness, "state", None), "mutation_epoch", None)
    out = fn(harness, **args)
    # Keep the evidence contract complete even when a layout helper only
    # mutates the in-memory Presentation. Mutators that already record a more
    # specific change are not double-counted.
    if name in _PPT_MUTATORS and epoch_before is not None and harness.state.mutation_epoch == epoch_before:
        harness.state.record_change(f"deck:{name}")
    if out is None:
        return ""
    return out if isinstance(out, str) else json.dumps(out, ensure_ascii=False)
