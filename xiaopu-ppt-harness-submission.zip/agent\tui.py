"""Xiaopu Agent — 1:1 Claude Code Replica CLI/TUI.

Direct 1:1 clone of Anthropic's Claude Code terminal interface layout,
formatting, spinner indicators, slash commands, and stdout stream.
"""
from __future__ import annotations

import json
import sys
from typing import Any

from rich.console import Console
from rich.markdown import Markdown

from . import config
from .demo import run_demo
from .harness import Harness
from .tools.registry import dispatch
from .redact import redact

console = Console()

CLAUDE_HELP = """\
Xiaopu Agent commands:

  <task>         run the agent on a task
  /new           reset session memory and deck
  /info          show slide deck structure
  /verify        run structural verifier
  /save [path]   save deck to file (default workspace/deck.pptx)
  /demo [task]   run offline demo mode
  /help          show this help message
  /exit, /quit   exit the session
"""


class ClaudeCodeReplicaUI:
    def __init__(self, model: str | None = None) -> None:
        config.load_dotenv()
        self._model = model
        self.h = Harness(model=self._model)
        self.has_key = bool(config.api_key() or config.anthropic_api_key())
        self.h.attach_printer(self._on_tool)

    def print_welcome(self) -> None:
        mode_str = "online" if self.has_key else "offline demo"
        console.print()
        console.print(f"[bold white]Xiaopu Agent v0.2.0[/] [dim white]({self.h.llm.model} · {mode_str})[/]")
        console.print("[dim white]Type /help for help, /exit to quit.[/]")
        console.print()

    def _on_tool(self, name: str, args: str, out: str) -> None:
        try:
            parsed = json.loads(args)
            pretty_args = json.dumps(parsed, ensure_ascii=False)
            if len(pretty_args) > 120:
                pretty_args = pretty_args[:120] + "..."
        except Exception:
            pretty_args = args[:120]
        pretty_args = redact(pretty_args)

        # Claude Code Tool Call Formatting
        console.print(f"  [bold cyan]> {name}[/][dim white]({pretty_args})[/]")
        for line in (out or "").splitlines()[:6]:
            console.print(f"    [dim white]{redact(line)}[/]")
        console.print()

    def run_interactive(self) -> int:
        self.print_welcome()

        while True:
            try:
                console.print("[bold white]> [/]", end="")
                user_input = input().strip()
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim white]Exiting.[/]")
                break

            if not user_input:
                continue

            parts = user_input.split(None, 1)
            cmd = parts[0].lower()

            if cmd in ("/quit", "/exit", "/q"):
                break
            if cmd in ("/help", "/h"):
                console.print(CLAUDE_HELP)
                continue
            if cmd == "/new":
                self.h.reset()
                console.print("[dim white]Session reset.[/]\n")
                continue
            if cmd == "/info":
                info = dispatch("deck_info", "{}", self.h)
                console.print(f"[dim white]{info}[/]\n")
                continue
            if cmd == "/verify":
                report = dispatch("ppt_verify", "{}", self.h)
                console.print(f"[dim white]{report}[/]\n")
                continue
            if cmd == "/save":
                p = parts[1].strip() if len(parts) > 1 else None
                res = dispatch("save_deck", json.dumps({"path": p}) if p else "{}", self.h)
                console.print(f"[bold white]Saved:[/] {res}\n")
                continue
            if cmd == "/demo":
                task_str = parts[1] if len(parts) > 1 else "创建一份咖啡主题介绍"
                self._execute(task_str, force_demo=True)
                continue

            self._execute(user_input)

        return 0

    def _execute(self, task: str, force_demo: bool = False) -> None:
        with console.status("[dim white]⠋ Working...[/]", spinner="dots"):
            try:
                if self.has_key and not force_demo:
                    reply = self.h.run(task)
                    console.print()
                    console.print(Markdown(reply))
                    console.print()
                else:
                    reply = run_demo(self.h, task)
                    console.print()
                    console.print(f"[white]{reply}[/]")
                    console.print()
            except Exception as e:
                console.print(f"[red]Error:[/] {type(e).__name__}: {e}\n")


def run_tui(model: str | None = None) -> int:
    return ClaudeCodeReplicaUI(model=model).run_interactive()
