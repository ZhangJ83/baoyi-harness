import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable

from . import config
from .tools.registry import dispatch, select_tools
from .state import RunState
from .hooks import PostToolHook, PreToolHook, ToolEvent

_READ_ONLY = {"read_file", "list_dir", "glob_files", "search_text", "git_status", "git_diff", "deck_info", "ppt_verify"}


class Harness:
    """Agentic loop: plan -> act -> observe -> verify.

    The LLM returns tool_calls; we execute them, feed results back,
    and continue until the model stops calling tools. Callable repeatedly:
    each `run()` call keeps the session (messages + deck), like a terminal chat.
    """

    def __init__(self, model: str | None = None, max_steps: int | None = None, controller_policy: str = "cegar_h"):
        config.load_dotenv()
        from .llm import make_client

        self.llm = make_client(model)
        self.max_steps = max_steps or config.max_steps()
        self.messages: list[dict[str, Any]] = []
        self.deck = None
        self.on_tool: Callable[[str, str, str], None] = lambda name, args, out: None
        self.started = False
        self.state = RunState()
        self._done: str | None = None
        self.pre_tool_hooks: list[PreToolHook] = []
        self.post_tool_hooks: list[PostToolHook] = []
        self.loaded_skills: set[str] = set()
        from .controller_policies import PolicyGuard
        self.controller_policy = controller_policy
        self.policy_guard = PolicyGuard(controller_policy)

    def attach_printer(self, printer: Callable[[str, str, str], None]) -> None:
        self.on_tool = printer

    def add_pre_tool_hook(self, hook: PreToolHook) -> None:
        self.pre_tool_hooks.append(hook)

    def add_post_tool_hook(self, hook: PostToolHook) -> None:
        self.post_tool_hooks.append(hook)

    def _system_prompt(self, task: str) -> str:
        from . import memory
        from .context import workspace_context
        from .skills import catalog, discover, match
        from .controller_policies import policy_instruction

        rules = memory.load_rules()
        notes = memory.load_notes()
        read_only_task = "do not modify" in task.lower() or "read-only" in task.lower()
        skills = [] if read_only_task else discover()
        selected = [] if read_only_task else match(task, skills)
        self.loaded_skills.update(skill.name for skill in selected)
        read_only_hint = ""
        if "do not modify" in task.lower() or "read-only" in task.lower():
            read_only_hint = (
                "\n--- Read-only task constraint ---\n"
                "This is a read-only task. Use at most two targeted inspection calls, then call finish immediately with the evidence. "
                "Do not explore unrelated files, run broad scans, or repeat observations.\n"
            )
        return (
            "You are an autonomous coding + PowerPoint agent running inside a harness.\n"
            "You get a task, and you work it step by step using tools. "
            "The harness gives you: tools, execution, and a verification layer.\n"
            "Rules:\n"
            "1. Inspect before editing. Maintain a short task list for multi-step work.\n"
            "2. Prefer small verifiable steps. After changes, run the cheapest relevant verifier.\n"
            "3. If a tool errors, read the error, adjust, retry. Never repeat the exact same call.\n"
            "4. For PPT work, inspect the deck, choose layouts intentionally, save, verify, and render-inspect when available.\n"
            "5. Call finish only after citing concrete verification evidence.\n"
            "6. Everything you write must be placed under the workspace directory.\n"
            "7. A successful shell exit is not enough by itself: inspect test output and ensure the command exercised the changed behavior.\n"
            "8. Do not weaken, delete, or bypass tests merely to obtain a passing result.\n"
            "9. Classify the request before acting. For read-only/explanation tasks, inspect only the minimum relevant artifacts, then call finish; do not create a task list or run broad repository scans.\n"
            "10. For a small single-file task, use at most one inspect action, one mutation, one focused verifier, and finish. Avoid re-reading unchanged files.\n"
            "11. Prefer a concise final answer after evidence is sufficient; do not spend turns narrating plans or repeating successful observations.\n"
            f"12. Active controller intervention: {getattr(self, 'controller_policy', 'cegar_h')}. {policy_instruction(getattr(self, 'controller_policy', 'cegar_h'))}\n"
            + ("\n--- Workspace context ---\n" + workspace_context() if not read_only_task else "")
            + "\n"
            + "\n--- Available skills ---\n"
            + catalog(skills)
            + "\n"
            + ("\n--- Loaded skill instructions ---\n" + "\n\n".join(skill.body for skill in selected) + "\n" if selected else "")
            + (f"\n--- Project rules ---\n{rules}\n" if rules else "")
            + (f"\n--- Session notes ---\n{notes}\n" if notes else "")
            + read_only_hint
        )

    def reset(self) -> None:
        self.messages = []
        self.deck = None
        self.started = False
        self.state = RunState()
        self._done = None
        self.loaded_skills = set()
        from .controller_policies import PolicyGuard
        self.policy_guard = PolicyGuard(getattr(self, "controller_policy", "cegar_h"))

    def run(self, task: str) -> str:
        read_only_task = "do not modify" in task.lower() or "read-only" in task.lower()
        if not self.started:
            self.messages = [{"role": "system", "content": self._system_prompt(task)}]
            self.started = True
        else:
            from .skills import discover, match
            newly_selected = [skill for skill in match(task, discover()) if skill.name not in self.loaded_skills]
            if newly_selected:
                self.loaded_skills.update(skill.name for skill in newly_selected)
                self.messages.append({"role": "system", "content": "Dynamically loaded skill instructions:\n" + "\n\n".join(skill.body for skill in newly_selected)})
        self.messages.append({"role": "user", "content": task})
        self.state.goal = task
        self._done = None
        # A model can satisfy the tool protocol while making no progress (for
        # example, issuing the same failed search/edit forever).  Keep a small
        # circuit breaker independent of the token budget so these stalls do
        # not consume the whole provider allocation.
        last_signature: str | None = None
        same_signature_streak = 0

        for _ in range(self.max_steps):
            if self.state.total_tokens >= config.max_total_tokens():
                return "(loop stopped: token budget reached)"
            remaining = config.max_total_tokens() - self.state.total_tokens
            generated_remaining = config.max_generated_output_tokens() - self.state.generated_output_tokens
            # Allocate output budget per turn from the remaining allowance.
            # This prevents a final response from requesting the full default
            # cap and being rejected after it has already consumed the budget.
            if remaining < 256 or generated_remaining < 256:
                return "(loop stopped: insufficient token budget for another response)"
            if remaining <= config.max_output_tokens() * 2:
                budget_hint = "Budget is nearly exhausted. Do only the minimum final verification needed, then call finish; do not start new exploration."
                if not any(message.get("content") == budget_hint for message in self.messages[-3:] if message.get("role") == "user"):
                    self.messages.append({"role": "user", "content": budget_hint})
            prior_openai_cap = os.environ.get("OPENAI_MAX_TOKENS")
            prior_anthropic_cap = os.environ.get("ANTHROPIC_MAX_TOKENS")
            cap = str(min(config.max_output_tokens(), remaining, generated_remaining))
            os.environ["OPENAI_MAX_TOKENS"] = cap
            os.environ["ANTHROPIC_MAX_TOKENS"] = cap
            try:
                reply = self.llm.chat(self.messages, select_tools(task, self.deck is not None))
            finally:
                if prior_openai_cap is None:
                    os.environ.pop("OPENAI_MAX_TOKENS", None)
                else:
                    os.environ["OPENAI_MAX_TOKENS"] = prior_openai_cap
                if prior_anthropic_cap is None:
                    os.environ.pop("ANTHROPIC_MAX_TOKENS", None)
                else:
                    os.environ["ANTHROPIC_MAX_TOKENS"] = prior_anthropic_cap
            self.state.total_tokens += reply.total_tokens
            self.state.input_tokens += reply.input_tokens
            self.state.generated_output_tokens += reply.output_tokens
            self.state.provider_usage_authoritative = self.state.provider_usage_authoritative and reply.usage_authoritative
            # A provider may return more tokens than the remaining allowance in
            # one response.  Do not execute any tool calls from an over-budget
            # response; otherwise the harness would violate its own cost gate.
            if (self.state.total_tokens > config.max_total_tokens()
                    or self.state.generated_output_tokens > config.max_generated_output_tokens()):
                incomplete = [item for item in self.state.tasks if item.status.value in {"pending", "in_progress"}]
                if self.state.fresh_evidence() and not incomplete:
                    self.state.budget_overrun = True
                    self.state.final_summary = "(completed with budget overrun after fresh verification evidence)"
                    return self.state.final_summary
                return "(loop stopped: model response exceeded total token budget)"
            msg = reply.choices[0].message
            if not getattr(msg, "tool_calls", None):
                answer = msg.content or ""
                incomplete = [item for item in self.state.tasks if item.status.value in {"pending", "in_progress"}]
                if self.state.changed_files and not self.state.fresh_evidence():
                    self.messages.append({"role": "assistant", "content": answer})
                    self.messages.append({"role": "user", "content": "You changed files but provided no verification evidence. Run the relevant checks, inspect their output, then finish."})
                    continue
                if incomplete:
                    self.messages.append({"role": "assistant", "content": answer})
                    self.messages.append({"role": "user", "content": "The task list still contains unfinished items. Continue working or mark genuinely blocked items with evidence."})
                    continue
                self.state.final_summary = answer
                return answer

            self.messages.append(
                {
                    "role": "assistant",
                    "content": msg.content or "",
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in msg.tool_calls
                    ],
                }
            )

            results = self._execute_calls(msg.tool_calls)
            signatures = [f"{tc.function.name}:{tc.function.arguments}" for tc in msg.tool_calls]
            signature = "|".join(signatures)
            if signature == last_signature:
                same_signature_streak += 1
            else:
                last_signature = signature
                same_signature_streak = 1
            for tc in msg.tool_calls:
                text = results[tc.id]
                self.on_tool(tc.function.name, tc.function.arguments, text)
                self.messages.append({"role": "tool", "tool_call_id": tc.id, "content": text})
            if self._done:
                return self._done
            # Read-only benchmark tasks need evidence, not an open-ended agent
            # loop. After two targeted inspection calls, close deterministically
            # so prompt exploration cannot consume the entire provider budget.
            if read_only_task and self.state.tool_calls >= 2:
                evidence = "\n".join(results.values())
                self.state.final_summary = "Read-only inspection complete. Evidence:\n" + evidence[:6000]
                return self.state.final_summary
            if same_signature_streak >= 3 and not self.state.fresh_evidence():
                return "(loop stopped: repeated identical action without progress)"
            self._maybe_compact()

        return "(loop ended without a final answer: max_steps reached)"

    def _execute_calls(self, calls) -> dict[str, str]:
        if self.state.tool_calls + len(calls) > config.max_tool_calls():
            return {tc.id: "TOOL ERROR (BudgetExceeded): maximum tool-call budget reached" for tc in calls}
        self.state.tool_calls += len(calls)

        def execute(tc) -> str:
            arguments = tc.function.arguments
            try:
                if not hasattr(self, "policy_guard"):
                    from .controller_policies import PolicyGuard
                    self.controller_policy = getattr(self, "controller_policy", "cegar_h")
                    self.policy_guard = PolicyGuard(self.controller_policy)
                self.policy_guard.before_tool(tc.function.name, self.state)
                for hook in self.pre_tool_hooks:
                    arguments = hook(ToolEvent(tc.function.name, arguments))
                    if not isinstance(arguments, str):
                        raise TypeError("pre-tool hooks must return JSON argument text")
                tc.function.arguments = arguments
                fingerprint = f"{tc.function.name}:{arguments}"
                out = dispatch(tc.function.name, arguments, self)
                text = out if isinstance(out, str) else str(out)
                for hook in self.post_tool_hooks:
                    text = hook(ToolEvent(tc.function.name, arguments, text))
                    if not isinstance(text, str):
                        raise TypeError("post-tool hooks must return text")
                self.state.failures.pop(fingerprint, None)
                return text
            except Exception as exc:
                fingerprint = f"{tc.function.name}:{arguments}"
                count = self.state.failures.get(fingerprint, 0) + 1
                self.state.failures[fingerprint] = count
                hint = " Do not repeat this identical call." if count >= 2 else ""
                return f"TOOL ERROR ({type(exc).__name__}): {exc}.{hint}"

        parallel = len(calls) > 1 and all(tc.function.name in _READ_ONLY for tc in calls)
        if not parallel:
            return {tc.id: execute(tc) for tc in calls}
        outputs: dict[str, str] = {}
        with ThreadPoolExecutor(max_workers=min(4, len(calls))) as pool:
            futures = {pool.submit(execute, tc): tc.id for tc in calls}
            for future in as_completed(futures):
                outputs[futures[future]] = future.result()
        return outputs

    def _maybe_compact(self) -> None:
        total = sum(len(json.dumps(message, ensure_ascii=False, default=str)) for message in self.messages)
        # Compact before the history becomes provider-expensive.  The old
        # 48k-character threshold allowed a long tool transcript to consume
        # most of a task's total-token budget before the next useful action.
        if total > 30000:
            head = self.messages[:1]
            last_tool_turn = next(
                (index for index in range(len(self.messages) - 1, 0, -1) if self.messages[index].get("role") == "assistant" and self.messages[index].get("tool_calls")),
                None,
            )
            tail = self.messages[last_tool_turn:] if last_tool_turn is not None else self.messages[-4:]
            self.messages = head + [
                {
                    "role": "system",
                    "content": "Long history compacted. Durable working state follows:\n"
                    + self.state.compact()
                    + "\nRe-read source artifacts when exact details are required.",
                },
                {"role": "user", "content": "Continue the active task from the durable state and most recent tool results below."},
            ] + tail


if __name__ == "__main__":
    task = sys.argv[1] if len(sys.argv) > 1 else "create a 3-slide deck about coffee"
    print(Harness().run(task))
