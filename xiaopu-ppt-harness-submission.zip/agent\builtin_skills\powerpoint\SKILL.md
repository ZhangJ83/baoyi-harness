---
name: powerpoint
description: Create, modify, restyle, render, and verify PPT or PowerPoint slide decks and 演示文稿.
---

# PowerPoint workflow

1. Classify the request: create, edit, restyle, repair, or extract.
2. For an existing deck, call `open_deck`, `deck_info`, and `shape_inventory` before editing.
3. Write a slide-role outline. Use varied semantic layouts: cover, KPI, comparison,
   table, image, and concise content slides. Avoid repeated bullet-only pages.
4. Keep one main message per slide. Prefer short labels and evidence over paragraphs.
5. Save the deck, call `ppt_verify`, then call `render_deck` and
   `inspect_rendered_deck` when a renderer is available. Structural verification
   does not replace rendered-pixel inspection, and the deterministic pixel gate
   does not replace semantic review by a person or vision model.
6. Repair specific slides/shapes, rerun all applicable checks, and report the output path,
   slide count, checks performed, and any renderer limitation.
