"""Fail-closed validation of the frozen 12-instance SWE Verified protocol."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from datasets import Dataset


def validate(protocol_path: Path, arrow_path: Path, evaluator_root: Path) -> dict:
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    ds = Dataset.from_file(str(arrow_path))
    official = {row["instance_id"]: row for row in ds}
    instances = protocol.get("instances", [])
    rows = []
    for item in instances:
        row = official.get(item.get("instance_id"))
        rows.append({
            "instance_id": item.get("instance_id"),
            "present": row is not None,
            "repo_match": bool(row and row["repo"] == item.get("repo")),
            "base_commit_match": bool(row and row["base_commit"] == item.get("base_commit")),
            "problem_statement_present": bool(row and row.get("problem_statement")),
            "test_patch_present": bool(row and row.get("test_patch")),
        })
    ids = [x.get("instance_id") for x in instances]
    valid = bool(
        protocol.get("schema") == "official-swe-verified-protocol-v2"
        and protocol.get("source") == "SWE-bench/SWE-bench_Verified"
        and protocol.get("split") == "test"
        and len(instances) >= 10
        and len(ids) == len(set(ids))
        and protocol.get("minimum_score_eligible_reports", 0) >= 10
        and all(r["present"] and r["repo_match"] and r["base_commit_match"]
                and r["problem_statement_present"] and r["test_patch_present"] for r in rows)
        and (evaluator_root / "swebench/harness/run_evaluation.py").is_file()
    )
    return {
        "schema": "official-swe-verified-readiness-v2",
        "valid": valid,
        "protocol_sha256": hashlib.sha256(protocol_path.read_bytes()).hexdigest(),
        "dataset_cache_sha256": hashlib.sha256(arrow_path.read_bytes()).hexdigest(),
        "official_dataset_size": len(ds),
        "n_frozen_instances": len(instances),
        "n_repositories": len({x.get("repo") for x in instances}),
        "official_evaluator_present": (evaluator_root / "swebench/harness/run_evaluation.py").is_file(),
        "score_eligible_reports": 0,
        "model_run_complete": False,
        "claim_boundary": "ready protocol and local official metadata; no new model patches or official scores",
        "rows": rows,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--dataset-arrow", type=Path, required=True)
    p.add_argument("--evaluator-root", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    result = validate(a.protocol, a.dataset_arrow, a.evaluator_root)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
