"""Build a fail-closed model-generated PPT evaluation report from raw artifacts."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import zipfile
from pathlib import Path


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def weighted_kappa(a: list[int], b: list[int]) -> float:
    n = len(a)
    if n == 0 or n != len(b):
        return float("nan")
    observed = sum(((x - y) / 4) ** 2 for x, y in zip(a, b)) / n
    ca = [a.count(i) / n for i in range(1, 6)]
    cb = [b.count(i) / n for i in range(1, 6)]
    expected = sum(ca[i - 1] * cb[j - 1] * (((i - j) / 4) ** 2) for i in range(1, 6) for j in range(1, 6))
    return 1.0 if expected == 0 and observed == 0 else (float("nan") if expected == 0 else 1 - observed / expected)


def icc_2_1(rows: list[tuple[float, float]]) -> float:
    n, k = len(rows), 2
    if n < 2:
        return float("nan")
    row_means = [sum(row) / k for row in rows]
    col_means = [sum(row[j] for row in rows) / n for j in range(k)]
    grand = sum(row_means) / n
    msr = k * sum((value - grand) ** 2 for value in row_means) / (n - 1)
    msc = n * sum((value - grand) ** 2 for value in col_means) / (k - 1)
    mse = sum((rows[i][j] - row_means[i] - col_means[j] + grand) ** 2 for i in range(n) for j in range(k)) / ((n - 1) * (k - 1))
    denominator = msr + (k - 1) * mse + k * (msc - mse) / n
    return float("nan") if denominator == 0 else (msr - mse) / denominator


def validate(protocol_path: Path, raw_root: Path, mapping_path: Path, score_paths: list[Path]) -> dict:
    protocol = load(protocol_path)
    mapping = load(mapping_path)
    errors: list[str] = []
    dimensions = protocol["blind_review"]["dimensions"]
    expected = {(system, task["id"]) for system in protocol["systems"] for task in protocol["tasks"]}
    rows = mapping.get("artifacts", [])
    keyed = {(row.get("system"), row.get("task_id")): row for row in rows}
    if set(keyed) != expected or len(rows) != len(expected):
        errors.append("anonymous_mapping_task_system_mismatch")
    anonymous_ids = [row.get("anonymous_id") for row in rows]
    if len(anonymous_ids) != len(set(anonymous_ids)) or any(not value for value in anonymous_ids):
        errors.append("anonymous_ids_invalid_or_duplicate")
    protocol_hash = digest(protocol_path)
    rendered = 0
    for system, task_id in sorted(expected):
        folder = raw_root / system / task_id
        deck, pdf, montage = folder / "deck.pptx", folder / "deck.pdf", folder / "montage.png"
        structural, pixels, trace = folder / "structural_report.json", folder / "pixel_audit.json", folder / "generation_trace.json"
        required = [deck, pdf, montage, structural, pixels, trace]
        if any(not path.is_file() for path in required):
            errors.append(f"{system}/{task_id}:missing_required_artifact")
            continue
        slide_pngs = sorted((folder / "slides").glob("*.png"))
        if not zipfile.is_zipfile(deck) or pdf.read_bytes()[:4] != b"%PDF" or montage.read_bytes()[:8] != b"\x89PNG\r\n\x1a\n" or not slide_pngs:
            errors.append(f"{system}/{task_id}:invalid_artifact_signature_or_missing_slides")
            continue
        if any(path.read_bytes()[:8] != b"\x89PNG\r\n\x1a\n" for path in slide_pngs):
            errors.append(f"{system}/{task_id}:invalid_slide_png")
            continue
        structure, pixel, generation = load(structural), load(pixels), load(trace)
        if not (structure.get("valid") is True and structure.get("opens") is True and structure.get("overlap_count") == 0 and structure.get("overflow_count") == 0 and structure.get("unresolved_placeholders") == 0):
            errors.append(f"{system}/{task_id}:structural_gate_failed")
        if not (pixel.get("pass") is True and pixel.get("rendered_png_count") == len(slide_pngs)):
            errors.append(f"{system}/{task_id}:pixel_gate_failed")
        if not (generation.get("model_generated") is True and generation.get("system") == system and generation.get("task_id") == task_id and generation.get("protocol_sha256") == protocol_hash):
            errors.append(f"{system}/{task_id}:generation_trace_mismatch")
        row = keyed.get((system, task_id), {})
        if row.get("deck_sha256") != digest(deck):
            errors.append(f"{system}/{task_id}:deck_hash_mapping_mismatch")
        rendered += 1
    if len(score_paths) != 2:
        errors.append("exactly_two_reviewer_score_files_required")
    scores = [load(path) for path in score_paths] if len(score_paths) == 2 and all(path.is_file() for path in score_paths) else []
    by_reviewer: list[dict[str, dict]] = []
    for index, payload in enumerate(scores):
        if payload.get("locked_before_adjudication") is not True:
            errors.append(f"reviewer_{index + 1}:form_not_locked")
        entries = payload.get("scores", [])
        lookup = {row.get("anonymous_id"): row for row in entries}
        if set(lookup) != set(anonymous_ids) or len(entries) != len(anonymous_ids):
            errors.append(f"reviewer_{index + 1}:score_set_mismatch")
        for artifact_id, row in lookup.items():
            values = row.get("dimensions", {})
            if set(values) != set(dimensions) or any(not isinstance(value, int) or value < 1 or value > 5 for value in values.values()):
                errors.append(f"reviewer_{index + 1}:{artifact_id}:invalid_dimensions")
        by_reviewer.append(lookup)
    kappas: dict[str, float] = {}
    icc = float("nan")
    if len(by_reviewer) == 2 and not any("reviewer_" in error for error in errors):
        for dimension in dimensions:
            a = [by_reviewer[0][artifact_id]["dimensions"][dimension] for artifact_id in anonymous_ids]
            b = [by_reviewer[1][artifact_id]["dimensions"][dimension] for artifact_id in anonymous_ids]
            kappas[dimension] = weighted_kappa(a, b)
        overall = []
        for artifact_id in anonymous_ids:
            overall.append(tuple(sum(by_reviewer[r][artifact_id]["dimensions"].values()) / len(dimensions) for r in range(2)))
        icc = icc_2_1(overall)
    finite_agreement = math.isfinite(icc) and all(math.isfinite(value) for value in kappas.values())
    if scores and not finite_agreement:
        errors.append("agreement_not_finite")
    valid = not errors and rendered == 36
    return {
        "schema": "model-generated-ppt-evaluation-v1",
        "valid": valid,
        "protocol_sha256": protocol_hash,
        "protocol_frozen_before_generation": True,
        "model_generated": valid,
        "paired_task_set": set(keyed) == expected,
        "n_tasks": 12,
        "n_systems": 3,
        "rendered_decks": rendered,
        "blind_review": {
            "complete": valid,
            "n_reviewers": len(scores),
            "agreement_metric": icc if math.isfinite(icc) else None,
            "icc_2_1": icc if math.isfinite(icc) else None,
            "quadratic_weighted_kappa": kappas,
            "forms_locked_before_adjudication": len(scores) == 2 and all(payload.get("locked_before_adjudication") is True for payload in scores),
            "raw_score_files_sha256": [digest(path) for path in score_paths if path.is_file()],
        },
        "errors": errors,
        "claim_boundary": "Evaluation completeness and agreement only; performance superiority requires separate paired statistics.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, default=Path("benchmarks/pptbench_model_eval_v2.json"))
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--mapping", type=Path, required=True)
    parser.add_argument("--scores", type=Path, action="append", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = validate(args.protocol, args.raw_root, args.mapping, args.scores)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0 if result["valid"] else 2)


if __name__ == "__main__":
    main()
