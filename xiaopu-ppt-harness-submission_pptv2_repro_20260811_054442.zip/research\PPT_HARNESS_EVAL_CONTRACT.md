# PPT harness evaluation contract

## Research questions

1. Does mutation-scoped evidence prevent false completion after a deck is edited?
2. Does the reconstructed render-feedback loop reduce structural and rendered-pixel failures compared with save-only and structural-only loops?
3. Can the same harness support creation, text modification, geometry/layout repair, slide deletion, and slide reordering without bypassing verification?

## Frozen systems

- `save_only`: create or edit and save.
- `structural_only`: save plus `ppt_verify`.
- `render_feedback`: save, structural verification, rendering, rendered-pixel audit, targeted repair, and re-verification.

## Primary metrics

- task success under deterministic task requirements;
- false completion after a post-verification mutation;
- structural overflow/boundary/overlap findings;
- blank-render and edge-content findings;
- tool calls, turns, wall-clock, and verifier calls.

## Evidence tiers

- unit/regression tests establish tool and invariant behavior;
- deterministic fixtures establish scorer behavior;
- model-generated decks establish agent-loop behavior;
- blinded human or vision review is required for aesthetic claims.

Deterministic pixel checks must never be reported as semantic visual quality.

## Promotion gate

A claim is paper-facing only when raw artifacts, task manifests, common budgets, task-level outcomes, and current-epoch evidence are persisted. Small smoke tests remain prototype evidence.

## Frozen model-evaluation v2

`benchmarks/pptbench_model_eval_v2.json` supersedes the five-fixture v1 manifest
for model evaluation. It freezes 12 tasks across Xiaopu, Claude Code and Codex:
six from-scratch tasks and six modification/repair tasks whose input deck hashes
are pinned. The expected result is 36 model-generated decks, each rendered by
the same renderer and accompanied by PDF, slide PNGs, montage, structural report
and pixel audit. Two blinded reviewers use the mandatory anchored rubric in
`benchmarks/pptbench_review_rubric.md`; adjudication is excluded from the
primary analysis.

`workspace/results/pptbench_model_eval_v2_validation.json` proves only that the
protocol and local assets are ready. It is not model-generation, rendering or
human-review evidence and cannot satisfy the objective gate.
