import json
import math
from pathlib import Path

from benchmarks.validate_model_generated_ppt_eval import icc_2_1, validate, weighted_kappa


ROOT = Path(__file__).resolve().parents[1]


def test_agreement_metrics_are_one_for_identical_nonconstant_scores():
    values = [1, 2, 3, 4, 5, 2, 4]
    assert weighted_kappa(values, values) == 1.0
    assert math.isclose(icc_2_1([(float(value), float(value)) for value in values]), 1.0)


def test_result_validator_fails_closed_without_36_raw_artifacts(tmp_path):
    mapping = tmp_path / "mapping.json"
    mapping.write_text(json.dumps({"artifacts": []}), encoding="utf-8")
    score1 = tmp_path / "r1.json"
    score2 = tmp_path / "r2.json"
    for path in (score1, score2):
        path.write_text(json.dumps({"locked_before_adjudication": True, "scores": []}), encoding="utf-8")
    result = validate(
        ROOT / "benchmarks/pptbench_model_eval_v2.json",
        tmp_path / "raw",
        mapping,
        [score1, score2],
    )
    assert result["valid"] is False
    assert result["model_generated"] is False
    assert "anonymous_mapping_task_system_mismatch" in result["errors"]
    assert result["rendered_decks"] == 0
