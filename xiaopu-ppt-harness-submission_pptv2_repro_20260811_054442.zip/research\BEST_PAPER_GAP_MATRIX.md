# ICLR Best Paper gap matrix

Audit time: 2026-08-11 05:25 CST

This matrix is deliberately strict: a green controlled demo is not promoted to
a publication-scale claim. Each row names the evidence that would close the
gap and the current blocker.

| Requirement | Current evidence | Status | Exact closure condition | Next action |
|---|---|---|---|---|
| Core problem and mechanism | CEGAR-H formulation, mutation epochs, typed evidence, adaptive action table | supported in prototype | Independent implementation audit and real-task ablation | Freeze runtime config and publish code path |
| Fresh-evidence safety | 97-test regression, post-edit certificate rejection, controlled PPT trace, static audit of 14 registered PPT mutators | controlled-supported | Runtime mutation instrumentation coverage audit across all mutators and external side effects | Add property-based mutation trace and external-side-effect boundary test |
| Theory | Plug-in bounds, correlation bound, dynamic-oracle counterexample, finite checks | bounded-supported | Formal proof review with assumptions checked line by line | External theory review |
| Synthetic mechanism effect | 20-seed paired ablations, calibration shift, held-out calibration | synthetic-only | Held-out real-task trajectories with cost/risk labels | Collect real traces under fixed budget |
| PPT artifact workflow | 4-slide rendered demo, 4 PNGs, montage, structural score 1.0, pixel audit pass | controlled-rendered-demo | At least 12 paired tasks across 3 systems, 36+ rendered decks, and at least two-reviewer blind scoring with agreement | Freeze prompts/sources, then generate after credential and reviewer access |
| Terminal-Bench | 3/241 v2 pilot tasks, 3/3; v3 18-task protocol and adapters dry-run | pilot-only / prospective-ready except live smoke | Exact frozen 18-task v3 run with valid per-task parity ledgers; full score for leaderboard claims | Inject credential, pass non-scored smoke, then run pinned slice |
| SWE-bench Verified | 1 score-eligible instance | agent-pilot-only | At least 10 instances for multi-instance evidence; full Verified for benchmark claim | Run exact-commit evaluator |
| Competitor comparison | 3-task v2 raw comparison; v2 parity false; v3 gateway/hook/parity verifier implemented | exploratory-only | Same 18 task IDs, 4,500 generated-token / 60 covered-tool / 180-second caps, valid parity, paired CI and exact tests | Run authenticated live smoke and frozen v3 comparison |
| Causal attribution | Controller validated in simulator; objective gate now separates synthetic E8 from real E9 | missing real causality | Direct/always-verify/evidence-only/CEGAR-H on at least 12 paired real artifact tasks with predefined outcomes | Run after authenticated access on a campaign-capable execution surface |
| Independent review | Local skeptical review and packet only | pending | Dated hash-pinned report and non-author/conflict attestation | Send refreshed paper and evidence packet |
| Claim boundary | Machine audit explicitly reports incomplete objective | honest | Only promote claims whose row is closed | Keep claim gate fail-closed |

## Decision

The strongest current submission is a bounded theory-and-engineering paper with
a controlled rendered PPT demonstration. It is not an ICLR Best Paper claim.
The next executable evidence step is the authenticated non-scored v3 smoke,
followed by the 18-task matched slice. The real controller campaign, paired
model-generated PPT evaluation, multi-instance SWE-bench, and external review
remain separately required; none can be substituted by the synthetic E8 run or
the controlled four-slide demo.
